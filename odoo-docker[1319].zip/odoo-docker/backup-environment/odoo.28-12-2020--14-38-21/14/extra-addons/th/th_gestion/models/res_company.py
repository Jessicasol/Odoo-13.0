# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from string import ascii_letters, digits

class Company(models.Model):    
    _inherit = ['res.company']    
    _rec_name = 'siglas'
    
    siglas = fields.Char(size=6)       

    def name_get(self):
        result = []
        for company in self:
            if (company.siglas):
                siglas = '(' + company.siglas + ') ' + company.name                
            else:
                siglas = '(' + ') ' + company.name
            result.append((company.id, siglas))    
        return result    
    
    def transformar_mayuscula(self,values):   
        if("siglas" in values):        #verifica si existe la clave siglas en diccionario        
            if not set(str(values['siglas'])).difference(ascii_letters):                         
                values['siglas'] = values['siglas'].upper()
            else:
                raise ValidationError("Caracteres Invalidos en campo SIGLAS")
       
    @api.model
    def create(self, values):  
        self.transformar_mayuscula(values)
        result = super(Company, self).create(values)    
        return result
    
    def write(self, values): 
        self.transformar_mayuscula(values)       
        result = super(Company, self).write(values)        
        return result  