# -*- coding: utf-8 -*-
# from odoo import http


# class ThGestion(http.Controller):
#     @http.route('/th_gestion/th_gestion/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/th_gestion/th_gestion/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('th_gestion.listing', {
#             'root': '/th_gestion/th_gestion',
#             'objects': http.request.env['th_gestion.th_gestion'].search([]),
#         })

#     @http.route('/th_gestion/th_gestion/objects/<model("th_gestion.th_gestion"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('th_gestion.object', {
#             'object': obj
#         })
