# Gestion Talento Humano

Proyecto que contendrá la migración de los sistemas de Personal y llevará la gestión del Talento Humano de la Armada del Ecuador
Modulo que se debe instalar => th_gestion_hr