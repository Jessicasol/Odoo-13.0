# -*- coding: utf-8 -*-

from . import hr_departamento
from . import hr_grado_militar
from . import hr_employee
from . import hr_employee_public
from . import hr_estructura_proceso