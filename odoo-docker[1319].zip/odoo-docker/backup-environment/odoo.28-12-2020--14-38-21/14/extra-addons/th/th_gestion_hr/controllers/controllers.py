# -*- coding: utf-8 -*-
# from odoo import http


# class ThGestionHr(http.Controller):
#     @http.route('/th_gestion_hr/th_gestion_hr/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/th_gestion_hr/th_gestion_hr/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('th_gestion_hr.listing', {
#             'root': '/th_gestion_hr/th_gestion_hr',
#             'objects': http.request.env['th_gestion_hr.th_gestion_hr'].search([]),
#         })

#     @http.route('/th_gestion_hr/th_gestion_hr/objects/<model("th_gestion_hr.th_gestion_hr"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('th_gestion_hr.object', {
#             'object': obj
#         })
