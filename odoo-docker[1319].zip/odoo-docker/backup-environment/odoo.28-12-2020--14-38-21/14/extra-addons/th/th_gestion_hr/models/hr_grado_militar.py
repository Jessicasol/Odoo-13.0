from odoo import models, fields, api
from odoo.exceptions import ValidationError


class GradoMilitar(models.Model):
    _name = 'hr.grado.militar'
    _description = 'hr.grado.militar' 
    
       
    grupo_id = fields.Many2one(string='Grupo', comodel_name='hr.grupo', ondelete='restrict')
    name = fields.Char(string='Abreviatura', )
    nombre_completo = fields.Char(string='Nombre Completo', )
    
    
class Especialidad(models.Model):
    _name = 'hr.especialidad'
    _description = 'hr.especialidad'    
    
    name = fields.Char(string='Abreviatura', )
    nombre_completo = fields.Char(string='Nombre Completo', )
    

    
      
class Grupo(models.Model):
    _name = 'hr.grupo'
    _description = 'hr.grupo'    
    
    name = fields.Char(string='Nombre', )
    descripcion = fields.Char(string='Descripcion', )