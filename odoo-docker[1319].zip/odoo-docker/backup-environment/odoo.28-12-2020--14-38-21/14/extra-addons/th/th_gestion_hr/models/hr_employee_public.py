# -*- coding: utf-8 -*-

from odoo import models, fields, api


class x_HrEmployeePublic(models.Model):
    _inherit = ['hr.employee.public']   
           
    grado_id = fields.Many2one(readonly=True )   
    especialidad_id = fields.Many2one(readonly=True) 
    
    

    
    
    
    

  