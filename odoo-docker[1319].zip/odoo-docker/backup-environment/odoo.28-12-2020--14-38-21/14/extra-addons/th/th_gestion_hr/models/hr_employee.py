# -*- coding: utf-8 -*-

from odoo import models, fields, api


class x_Employee(models.Model):
    _inherit = ['hr.employee']        
    
    grado_id = fields.Many2one(string='Grado', comodel_name='hr.grado.militar')   
    especialidad_id = fields.Many2one(string='Especialidad', comodel_name='hr.especialidad') 
    
    

    def name_get(self):
        result = []       
        for table in self:                        
            l_name = str(table.grado_id.name) + "-" + str(table.especialidad_id.name) + " " + table.name
            result.append((table.id, l_name))
        return result
    
   
  