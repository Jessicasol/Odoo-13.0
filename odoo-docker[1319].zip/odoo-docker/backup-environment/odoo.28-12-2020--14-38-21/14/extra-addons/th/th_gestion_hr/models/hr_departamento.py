# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Departamento(models.Model):
    _inherit = ['hr.department']    
    _rec_name = 'name'    
    
    division_ids = fields.One2many(string='División', comodel_name='hr.division', inverse_name='departamento_id', )   
    
    
class Division(models.Model):
    _name = 'hr.division'
    _description = 'hr.division'    
    
    name = fields.Char(string='Nombre de la División', )         
    departamento_id = fields.Many2one(string='Nombre del Departamento', comodel_name='hr.department', ondelete='restrict', )  
    seccion_ids = fields.One2many(string='Seccion', comodel_name='hr.seccion', inverse_name='division_id', )       
    

class Seccion(models.Model):
    _name = 'hr.seccion'
    _description = 'hr.seccion'    
    
    name = fields.Char(string='Nombre de la Sección', )
    division_id = fields.Many2one(string='División', comodel_name='hr.division', ondelete='restrict', )  
    parent_id = fields.Many2one('hr.seccion', string='Seccion', index=True, )
    child_ids = fields.One2many('hr.seccion', 'parent_id', string='Seccion', )
   
    
    
    
    

  