from odoo.exceptions import ValidationError

from odoo import models, fields, api
from string import ascii_letters, digits
import string 
import time
import datetime

class Tripulantes(models.Model):    
    _inherit = ['hr.employee']

    # document_id = fields.Char(string='Cédula de Identidad', required=True, size=10 )    
 
   

    medical_record_ids = fields.One2many(string='Registro Medico',
       comodel_name='flight.medical.record', inverse_name='hr_employee_id', )
   
    crew_result_id = fields.Many2one( string='Resultado',
        comodel_name='flight.items', ondelete='restrict',
        domain=lambda self : [('catalogo_id', '=', self.env.ref('flight.catalogue_resultado').id)], related='medical_record_ids.result_id',
        readonly=False, store=True )
   
    crew_date_report = fields.Date(string='Fecha de Informe',
        related='medical_record_ids.date_report',readonly=False, store=True )

    crew_referent_document = fields.Char( string='Documento de Referencia',         
        size=70, related='medical_record_ids.referent_document',
        readonly=False, store=True )

    crew_observation = fields.Char(string='Observaciones', size=200,  
        related='medical_record_ids.observation', readonly=False, store=True )

    crew_state = fields.Selection(
        string='Estado',
        selection=[('ACTIVO', 'ACTIVO'), ('CADUCADO', 'CADUCADO')],default="ACTIVO",
        related='medical_record_ids.state', store=True )
   
   
    
    quatification_ids = fields.One2many(string='Habilitaciones',
        comodel_name='flight.qualification',inverse_name='tripulante_id',)
#  modelo_id
    registro_dotacion_ids = fields.One2many(string='Horas Registradas',
        comodel_name='flight.registro.dotacion',inverse_name='tripulante_id', domain=[('horas_de_vuelo_related','>',0)])

    modelo_id_related = fields.Many2one( string='Resultado',
        ondelete='restrict',
        related='registro_dotacion_ids.modelo_id_related',
        domain="[('id', '=', tripulante_id)]",
        readonly=True )

    hora_fin_related = fields.Datetime( string='Resultado',
        ondelete='restrict',
        related='registro_dotacion_ids.hora_fin_related',
        domain="[('id', '=', tripulante_id)]",
        readonly=True )

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):             
                values[k] = values.pop(k).upper()
    
    def write(self, values): 
        #self.transformar_mayuscula(values)    
        result = super(Tripulantes, self).write(values)    
        return result    
    
  

 
class MedicalRecord(models.Model):
    _name = 'flight.medical.record'
    _description = 'flight.medical.record'
    _order="date_report desc,create_date desc"
    _rec_name='result_id'
    
    result_id = fields.Many2one(
            string='Resultado',
            comodel_name='flight.items',
            ondelete='restrict',
            domain=lambda self : [('catalogo_id', '=', self.env.ref('flight.catalogue_resultado').id)],
            required=True    )
        
    date_report = fields.Date(
        string='Fecha de Informe',default=fields.Date.context_today, readonly=1, store=True
    )

    referent_document = fields.Char(
        string='Documento de Referencia',  
        required=True,
        size=70,  )

    observation = fields.Char(
        string='Observaciones',       
        size=200,  )
    
    hr_employee_id = fields.Many2one(
        string='Nombres',
        comodel_name='hr.employee',
        ondelete='restrict',       
        required=True,    )
   
    state = fields.Selection(
        string='Estado',
        selection=[('ACTIVO', 'ACTIVO'), ('CADUCADO', 'CADUCADO')],default="ACTIVO" )
    
    warning = {
            'title': 'Advertancia!',
            'message' : 'Your message.'
            }

    @api.onchange('result_id')
    def _onchange_field(self):        
            if(int(self.result_id.catalogo_id)!=5):
                self.result_id=""
    
    def transformar_mayuscula(self,values):        
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):             
                values[k] = values.pop(k).upper()   
  
    @api.model
    def create(self, values):  
        self.transformar_mayuscula(values)     
        result = super(MedicalRecord, self).create(values)       
        return result
    
    def write(self, values): 
        self.transformar_mayuscula(values)     
        result = super(MedicalRecord, self).write(values)                  
        return result
    
class Qualification(models.Model):
    _name = 'flight.qualification'
    _description = 'flight.qualification'
    _rec_name = 'tripulante_id'
    
    tripulante_id = fields.Many2one(string='Tripulantes', comodel_name='hr.employee', ondelete='restrict',) 
    
    aeronave_id = fields.Many2one(string='Aeronaves',comodel_name='flight.aircraft',ondelete='restrict', required=True )
        
    habilitacion_id = fields.Many2one(string='Habilitacion', comodel_name='flight.habilitaciones', ondelete='restrict', required=True )   
    
    fecha_habilitacion = fields.Date(string='Fecha de Habilitación', default=time.strftime('%Y-%m-%d'), required=True ) 

    fecha_ultimo_vuelo = fields.Date(string='Fecha Ultimo Vuelo', default=time.strftime('%Y-%m-%d'), required=True )
    
    modelo_related_id = fields.Many2one(string='modelo', related='aeronave_id.modelo_id', store=True)
   
    _sql_constraints = [
        ('name_unique',
         'UNIQUE(tripulante_id,aeronave_id,habilitacion_id)',
         "Ya se encuentra habilitado en la Aeronave seleccionada"),
    ]
    
    
    
    
    

   



   
   


   


   






    
    