from odoo.exceptions import ValidationError

from odoo import models, fields, api
from string import ascii_letters, digits
import string
import time
import datetime
import locale
from datetime import timedelta, date




class GestionPlanSemanal(models.Model):
    _name = 'flight.gestion.plan.semanal'
    _description = 'flight.gestion.plan.semanal'
    _rec_name = 'name'

   # GRUPO DEL USUARIO QUE GUARDO CODIGO DE SANDRO QUITO
    # @api.model
    # def default_user(self):
    #     flag=True 
    #     if(self.env.user.has_group('flight.group_operador_escuadron')):
    #         flag=self.env.user.has_group('flight.group_operador_escuadron')              
    #     return flag

    # flag = fields.Boolean(
    #     string='field_name', default=default_variable,
    # )
    _sql_constraints = [('name_unique', 'UNIQUE(name)', "No pueden existir Vuelos Planificados ni Ordenes de Vuelo duplicadas!!"),] 
    
    estados=[
        ('ACTIVO', 'ACTIVO'), 
        ('APROBADO_OPERADOR', 'OPERADOR'), 
        ('APROBADO_JEFE_OPERACIONES', 'JEFE DE OPERACIONES'), 
        ('APROBADO_COMANDANTE', 'COMANDANTE DE REPARTO'), 
        ('APROBADO_JEFE_OPERACIONES_COAVNA', 'JEFE DE OPERACIONES COAVNA'),
        ('APROBADO_COMANDANTE_COAVNA', 'COMANDANTE COAVNA'),        
        ('FIN', 'FINALIZADO')]
        
 #CAMPOS
    referencia_ov_pvs_id = fields.Many2one(string='Plan de Vuelo Semanal', comodel_name='flight.gestion.plan.semanal', ondelete='restrict', 
                                           domain=[('state','!=','FIN'),('vuelo_planificado','=','VUELO PLANIFICADO')])    
    vuelo_planificado = fields.Selection(string='Tipo de Vuelo', selection=[('VUELO PLANIFICADO', 'VUELO PLANIFICADO'), ('ORDEN DE VUELO',                                                              'ORDEN DE VUELO')],
                                        default='VUELO PLANIFICADO' )
    name = fields.Char(string='Descripción', size=80, required=True, default='VUELO PLANIFICADO')
    referencia = fields.Char(string='Referencia', size=80)
    fecha_inicial = fields.Date(string='Desde', default=time.strftime('%Y-%m-%d'),required=True )
    fecha_final = fields.Date(string='Hasta', )
    state =  fields.Selection(estados, string='ESTADO', readonly=True, copy=False, index=True, tracking=3, default='ACTIVO')      
    observacion_reparto = fields.Text(string='Observaciones Director Reparto:', )
    observacion_coavna = fields.Text(string='Observaciones Director COAVNA', )
    vuelosplanificados_ids = fields.One2many(string='Vuelos', comodel_name='flight.vuelos.planificados', inverse_name='gestion_plan_semanal_id',)
    
    @api.model
    def default_origen(self):        
         return self.env.user.company_id.id
    reparto_usuario_login = fields.Integer(string='reparto usuario logoneado', default=default_origen)    
    
    warning = {'title': 'Advertancia!', 'message': 'Your message.'}

 #BOTONES
  #BOTONES DE RETROCESO O RETORNO
   #BOTON PARA RETORNAR OPERADOR
    def action_retornar_operador(self):
        return self.funcion_aprobacion_general('ACTIVO')
        
   #BOTON PARA RETORNAR JEFE DE OPERACIONES
    def action_retornar_jefe_operaciones(self):
        return self.funcion_aprobacion_general('APROBADO_OPERADOR')
        
    def funcion(self, action,menu_root):       
        url = "/web#action=%s&model=flight.gestion.plan.semanal&view_type=list&menu_id=%s" % (action.id, menu_root.id)
        return {                   
            'name'     : 'Go to website',
            'res_model': 'ir.actions.act_url',
            'type'     : 'ir.actions.act_url',
            'target'   : 'self',
            'url'      : url
        } 
    
        
        
   #BOTON PARA RETORNAR JEFE DE OPERACIONES COAVNA
    def action_retornar_jefe_operaciones_coavna(self):
        return self.funcion_aprobacion_general('APROBADO_COMANDANTE')         
        
    def action_finalizar(self):
        self.write({'state': 'FIN',})
        action = self.env.ref('flight.action_planes_finalizados')
        menu_root = self.env.ref('flight.menu_flight')        
        return self.funcion(action,menu_root)

  #BOTONES DE APROBACION
   #BOTON PARA EL OPERADOR
    def action_confirm_operador(self):
        self.write({'state': 'APROBADO_OPERADOR'})          
        action = self.env.ref('flight.action_vizualizar_plan_vuelo_semanal_1')        
        menu_root = self.env.ref('flight.menu_flight')
        return self.funcion(action,menu_root)
    
    
    def funcion_aprobacion_general(self,estado): 
        self.write({'state': estado})            
        action = self.env.ref('flight.action_vizualizar_plan_vuelo_semanal_2')       
        menu_root = self.env.ref('flight.menu_flight')  
        url = "/web#action=%s&model=flight.gestion.plan.semanal&view_type=list&menu_id=%s" % (action.id, menu_root.id)
        return {                   
            'name'     : 'Go to website',
            'res_model': 'ir.actions.act_url',
            'type'     : 'ir.actions.act_url',
            'target'   : 'self',
            'url'      : url
        } 
        
   #BOTON PARA EL JEFE DE OPERACIONES
    def action_confirm_jefe_operaciones(self):    
        return self.funcion_aprobacion_general('APROBADO_JEFE_OPERACIONES')
        
   #BOTON PARA COMANDANTE
    def action_confirm_comandante(self):
        return self.funcion_aprobacion_general('APROBADO_COMANDANTE')
        
   #BOTON PARA COMANDANTE ORDEN VUELO
    def action_confirm_comandante_ov(self):
        return self.funcion_aprobacion_general('APROBADO_COMANDANTE_COAVNA') 
        
   #BOTON PARA EL JEFE DE OPERACIONES COAVNA
    def action_confirm_jefe_operaciones_coavna(self):
        return self.funcion_aprobacion_general('APROBADO_JEFE_OPERACIONES_COAVNA')    
        
   #BOTON PARA EL COMANDANTE COAVNA
    def action_confirm_comandante_coavna(self):
        return self.funcion_aprobacion_general('APROBADO_COMANDANTE_COAVNA')
    
 #FUNCIONES
    def transformar_mayuscula(self, values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):
                values[k] = values.pop(k).upper()

    def _check_name_marca_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe la marca: %s , no se permiten valores duplicados" % (record.name.upper())) 
    
    @api.constrains('name')
    def _check_(self):        
        for record in self:
            model_ids = record.search([('id', '!=',record.id)])
            for x in  model_ids:                 
                if(record.name == x.name):
                    raise ValidationError("No pueden existir Vuelos Planificados ni Ordenes de Vuelo duplicadas!!")         
    
    @api.model
    def create(self, values): 
        siglas =  self.env.company.siglas         
        if values['vuelo_planificado']=='ORDEN DE VUELO':          
           anio=time.strftime('%Y')                          
           values['name'] = "OV-"+ siglas +'-'+'OPE-'+str(anio)+self.env['ir.sequence'].next_by_code('flight.gestion.plan.semanal.secuencial')
        else:                
            # fecha= datetime.datetime.strptime(values['fecha_inicial'],"%Y-%m-%d").date()
            # mes=fecha.strftime("%B")                  
            palabra_mes = self.transformar_palabra_mes(int(values['fecha_inicial'][5:7]))           
            values['name'] = siglas+" - SEMANA DEL "+ values['fecha_inicial'][-2:]+" AL "+ values['fecha_final'][-2:]+" DE " + palabra_mes + " DEL " + values['fecha_inicial'][0:4]
        self.transformar_mayuscula(values)
        result = super(GestionPlanSemanal, self).create(values)
        return result
    
    def write(self, values):
        self.transformar_mayuscula(values)
        result = super(GestionPlanSemanal, self).write(values)
        return result

    @api.onchange('fecha_inicial')
    def _onchange_fecha_inicial(self):       
        if str(self.fecha_inicial) < str(datetime.datetime.now() - timedelta(days=2)):
            self.fecha_inicial = datetime.datetime.now() - timedelta(days=1)
            self.warning['message'] = "Fecha no puede ser menor a la fecha del actual"
            return {'warning': self.warning}

    @api.onchange('fecha_final')
    def _onchange_fecha_final(self):
        if(self.fecha_final):
            if str(self.fecha_final) < str(self.fecha_inicial):
                self.fecha_final = datetime.datetime.now()
                self.warning['message'] = "Fecha Final no puede ser menor a la fecha de Inicio"
                return {'warning': self.warning}

    def transformar_palabra_mes(self,mes):
        diccionario={"1":"ENERO", "2":"FEBRERO", "3":"MARZO", "4":"ABRIL", "5":"MAYO","6":"JUNIO", "7":"JULIO", "8":"AGOSTO", "9":"SEPTIEMBRE", 
                     "10":"OCTUBRE","11":"NOVIEMBRE","12":"DICIEMBRE"}     
        return diccionario.get(str(mes))
      
    @api.onchange('vuelo_planificado')
    def _onchange_name(self):
        if self.vuelo_planificado=='VUELO PLANIFICADO':
            self.name="VUELO PLANIFICADO"
            self.referencia=""
            self.referencia_ov_pvs_id=""             
        else:    
            self.name="ORDEN DE VUELO"             
            self.fecha_final=""    
      
#    VALORES POR DEFECTO PVS
    @api.model
    def default_get(self, fields):
        res = super(GestionPlanSemanal, self).default_get(fields)
        # SI ES JUEVES COMO REGLA DE NEGOCIO ELABORAR PLAN DE VUELO SEMANAL, GENERAR AUTOMATICAMENTE LA CABECERA LAS FECHAS
        if int(datetime.date.today().strftime("%w")) == 4:
            temp = int((datetime.datetime.now()+timedelta(days=10)).strftime("%m"))
            palabra_mes = self.transformar_palabra_mes(temp)
            res.update({
                'fecha_inicial': datetime.datetime.now()+timedelta(days=4),
                'fecha_final': datetime.datetime.now()+timedelta(days=10),
                'name': 'SEMANA DEL {} AL {} de {} del {}'.format((datetime.datetime.now()+timedelta(days=4)).strftime("%d"), (datetime.datetime.now()+timedelta(days=10)).strftime("%d"), palabra_mes, (datetime.datetime.now()+timedelta(days=10)).strftime("%Y"))
                # 'name': 'SEMANA DEL AL {}'.format(int(datetime.date.today().strftime("%w")))
            })
        return res  

   # FUNCION DEL ACTION SERVER
    # def action_server_plan_vuelo_semanal(self):
    #     c= self.env.ref('flight.group_jefe_operaciones_comando').id
    #     d= self.env.ref('flight.group_comandante_aviacion').id
    #     for x in self.env.user.groups_id.ids:
    #         if c == x or d == x:
    #             return {
    #                 'name': ('PLAN DE VUELO SEMANAL'),        
    #                 'domain': [('state', '=', 'APROBADO_COMANDANTE_COAVNA')],
    #                 'res_model': 'flight.gestion.plan.semanal',
    #                 'views': [(self.env.ref('flight.flight_list').id, 'tree'),(self.env.ref('flight.view_fligrew_form').id, 'form')],
    #                 'view_mode': 'tree,form',
    #                 'type': 'ir.actions.act_window',
    #             } 
                
    #     return {
    #         'name': ('PLAN DE VUELO SEMANAL'),        
    #         'domain': [('state', '=', 'APROBADO_COMANDANTE_COAVNA'),('reparto_usuario_login', '=', self.env.user.company_id.id)],
    #         'res_model': 'flight.gestion.plan.semanal',
    #         'views': [(self.env.ref('flight.flight_list').id, 'tree'),(self.env.ref('flight.view_fligrew_form').id, 'form')],
    #         'view_mode': 'tree,form',
    #         'type': 'ir.actions.act_window',
    #     } 
       
   
    def action_server_bandeja_entrada(self):
        a= self.env.ref('flight.group_jefe_operaciones_reparto').id
        b= self.env.ref('flight.group_comandante_reparto').id
        c= self.env.ref('flight.group_jefe_operaciones_comando').id
        d= self.env.ref('flight.group_comandante_aviacion').id        
        diccionario= {
                    'name': ('BANDEJA DE ENTRADA'),        
                    'domain': [(),()],
                    'res_model': 'flight.gestion.plan.semanal',
                    'views': [(self.env.ref('flight.view_flight_vizualizar_plan_vuelo_semanal_tree_2').id, 'tree'),(self.env.ref('flight.view_fligrew_form').id, 'form')],
                    'view_mode': 'tree,form',
                    'type': 'ir.actions.act_window',
                }
        
        for x in self.env.user.groups_id.ids:
            if a == x:
                diccionario['domain'] =  [('state', '=', 'APROBADO_OPERADOR'), ('reparto_usuario_login', '=', self.env.user.company_id.id), ]  
                break                      
            elif b == x:
                diccionario['domain'] = [('state', '=', 'APROBADO_JEFE_OPERACIONES'), ('reparto_usuario_login', '=', self.env.user.company_id.id),]     
                break           
            elif c == x:
                diccionario['domain'] = [('state', '=', 'APROBADO_COMANDANTE'),]
                break
            elif d == x:
                diccionario['domain'] = [('state', '=', 'APROBADO_JEFE_OPERACIONES_COAVNA'),] 
                break              
        return diccionario
            
                
    

class VuelosPlanificados(models.Model):
    _name = 'flight.vuelos.planificados'
    _description = 'flight.vuelos.planificados'
    _order = "fecha_vuelo asc"
    _rec_name="vuelo_planificado_ref"
    
    @api.model
    def _condicion(self):
        c= self.env.ref('flight.group_jefe_operaciones_comando').id 
        d= self.env.ref('flight.group_comandante_aviacion').id    
        if (c in self.env.user.groups_id.ids or d in self.env.user.groups_id.ids):
            return [('estado', '!=', 'NO OPERATIVO')]
        else:                 
            return [("escuadron_id2", "=", self.env.company.id),('estado', '!=', 'NO OPERATIVO')]    
    
    # @api.model
    # def _validacion(self):        
    #     [("escuadron_id2", "=", self.env.company.id),('estado', '!=', 'NO OPERATIVO')]
    #      return self.env.ref("tics_asset.items_origen_sistema").id  
    
    #warning = {'title': 'Advertancia!', 'message' : 'Your message.' }

   #Solucionar error de regla empleado - company (se la anexa en el domain de la vista)
    # @api.model
    # def default_origen(self):        
    #      return self.env.user.company_id.id
    # reparto_usuario_login_related = fields.Integer(string='reparto usuario logoneado', default=default_origen)
    
    # VER SI ES QUE VALE, SINO  STORE=TRUE
    reparto_usuario_login_related = fields.Integer(related='gestion_plan_semanal_id.reparto_usuario_login')
   #CAMPOS
    vuelo_planificado_ref = fields.Selection(related='gestion_plan_semanal_id.vuelo_planificado')
    fecha_inicial_related = fields.Date(string="Fecha",related='gestion_plan_semanal_id.fecha_inicial')
    fecha_final_related = fields.Date(related='gestion_plan_semanal_id.fecha_final')
    state_related = fields.Selection(related='gestion_plan_semanal_id.state', store=True)
    aeronave_id = fields.Many2one(string='Aeronave', domain=_condicion, comodel_name='flight.aircraft', ondelete='restrict', required=True)
    tipo_aeronave_id_related= fields.Many2one(string='Aeronave',related="aeronave_id.tipo_aeronave_id")
    matricula = fields.Char(string='matricula', related='aeronave_id.name', store=False)     
    mision = fields.Many2one(string='Mision', comodel_name='flight.mision.planvuelo', ondelete='restrict', required=True,
                             domain="[('aeronave_id', '=', aeronave_id)]",)       
    fecha_vuelo = fields.Date(string='Fecha', required=True,domain=[('fecha_vuelo', '>=', fields.Date.context_today)])
    fecha_presentar = fields.Date(string='FECHA', default=fields.Datetime.now,)
    hora = fields.Many2one(string='Hora', comodel_name='flight.items', ondelete='restrict',
                           domain=lambda self: [('catalogo_id', '=', self.env.ref('flight.catalogue_hora').id)], required=True)
    piloto_id = fields.Many2one(string='Piloto', comodel_name='flight.qualification', ondelete='restrict', required=True,)
    copiloto_id = fields.Many2one(string='Copiloto', comodel_name='flight.qualification', ondelete='restrict')
    ingeniero_vuelo_id = fields.Many2one(string='Ing.de vuelo', comodel_name='flight.qualification', ondelete='restrict')
    operador_electro_id = fields.Many2one(string='Ope. Electro/óptico', comodel_name='flight.qualification', ondelete='restrict')
    radarista_id = fields.Many2one(string='Radarista', comodel_name='flight.qualification', ondelete='restrict', )
    taco_id = fields.Many2one(string='Taco', comodel_name='flight.qualification', ondelete='restrict')
    rutas_ids = fields.One2many(string='Rutas', comodel_name='flight.rutas', inverse_name='vuelo_planificado_id', required=True)
    mecanico_ids = fields.Many2many(string='Mecánico', comodel_name='flight.qualification', relation='vuelo_planificado_mecanico_rel', column1='vueloplanificado_id', column2='mecanico_id', required=True,)
    electricista_ids = fields.Many2many(string='Electricista', comodel_name='flight.qualification', relation='vuelo_planificado_electricista_rel', column1='vueloplanificado_id', column2='electricista_id',)
    electronico_ids = fields.Many2many(string='Electrónico', comodel_name='flight.qualification', relation='vuelo_planificado_electronico_rel', column1='vueloplanificado_id', column2='electronico_id',)
    gestion_plan_semanal_id = fields.Many2one(string='Plan Semanal', comodel_name='flight.gestion.plan.semanal', ondelete='restrict',)
    state = fields.Selection( string='Estado', selection=[('PLANIFICADO', 'PLANIFICADO'), ('EJECUTADO', 'EJECUTADO'),('REVISADO', 'REVISADO'),('FIN', 'FINALIZADO')], default='PLANIFICADO')
        
    # horas_de_vuelo_related = fields.Float(string='Horas', related='rutas_ids.horas_de_vuelo', )    
    #  request.write({'solucion_ticket':self.descripcion,
    #                        'band_mesa_ayuda':True,
    #                        'es_crear_usuario':False,
    #                        'es_creacion':False,
    #                        'es_editar_categoria':True,
    #                        'execution_date': time.strftime('%Y-%m-%d %H:%M:%S'), 
    #                        'fecha_finalizacion': time.strftime('%Y-%m-%d %H:%M:%S')
    #                        })
    # item.rutas_ids.hora_inicio  = values['fecha_presentar']
    #             item.rutas_ids.hora_fin = values['fecha_presentar']
    
    def action_confirmacion(self):  
        for record in self.rutas_ids:             
            record.hora_inicio =  record.hora_decolage_tc 
            record.hora_fin =  record.hora_aterrizaje_tc              
        self.write({'state': 'EJECUTADO'})       
        return True     
    
    def action_realizado(self):                     
        self.write({'state': 'REVISADO'})       
        return True   
            
    def action_realizado2(self):                     
        self.write({'state': 'FIN'})       
        return True       
    
    def action_finalizacion(self):
        for linea in self.rutas_ids:
            #ADICIONAL UNA ALERTA POR SI PASA ALGO Y NO LLENA LA DOTACION Y MANDA A GUARDAR. SIENDO EJECUTADO UNA HORA DE VUELO. 
            if (linea.horas_de_vuelo!= False and linea.band_volo ==True) and (not linea.registro_dotacion_ids):
                raise ValidationError ("A BORRADO LA DOTACION, POR FAVOR INGRESE LA DOTACION EN LA RUTA %s - %s PARA CONTINUAR".format(linea.ruta_inicio_id,linea.ruta_fin_id))            
            # BORRAR DOTACION CUANDO HORAS DE VUELO SEA 0. PARA QUE NO REGISTRE
            if (linea.horas_de_vuelo == False):      
                linea.registro_dotacion_ids=[(5,0,0)]
                linea.num_aterrizaje_tierra = 0
                linea.num_aterrizaje_bordo = 0               
        self.write({'state': 'FIN'})       
        return True   
    
   #ONCHANGE LIMPIAR
    @api.onchange('aeronave_id')
    def _onchange_validacion_limpiar(self):
        if(int(self.aeronave_id)):
            self.piloto_id = ""
            self.copiloto_id = ""
            self.taco_id = ""
            self.ingeniero_vuelo_id = ""
            self.operador_electro_id = ""
            self.radarista_id = ""
            self.rutas_ids = [(5, 0, 0)]
            self.mecanico_ids = [(5, 0, 0)]
            self.electricista_ids = [(5, 0, 0)]
            self.electronico_ids = [(5, 0, 0)]
            self.mision = ""
          
    warning = {'title': 'Advertancia!', 'message': 'Your message.'}
   #VALIDACION FECHA VUELO < GPVS
    @api.onchange('fecha_vuelo')
    def _onchange_validacion_fecha_vuelopvs(self):
        if(self.fecha_vuelo):
            if str(self.fecha_vuelo) > str(self.fecha_final_related) or str(self.fecha_vuelo) < str(self.fecha_inicial_related):
                self.fecha_vuelo = ""
                self.warning['message'] = "Usted esta escogiendo un dia que no se encuentra entre las fechas del Plan de Vuelo Semanal"
                return {'warning': self.warning}

   #METODO CREATE, LLENAMOS HORA Y FECHA DECOLAJE Y ATERRIZAJE POR DEFECTO LA FECHA PLANIFICADA
    @api.model
    def create(self, values):
        result = super(VuelosPlanificados, self).create(values)
        for item in result:    
            if values['fecha_presentar']:
                item.rutas_ids.hora_inicio  = values['fecha_presentar']
                item.rutas_ids.hora_fin = values['fecha_presentar']
                item.rutas_ids.hora_decolage_tc = values['fecha_presentar']
                item.rutas_ids.hora_estimada_arribo_tc = values['fecha_presentar']
                item.rutas_ids.hora_aterrizaje_tc = values['fecha_presentar']
        return result
 
   #LLENAMOS 1 DIA MAS PARA IGUALAR DATE CON DATETIME Y UTILIZARLA EN EL CREATE 
    @api.onchange('fecha_vuelo')
    def _defualt_function(self):
        if self.fecha_vuelo:
            self.write({'fecha_presentar': self.fecha_vuelo+timedelta(days=1)})
            

class Rutas(models.Model):
    _name = 'flight.rutas'
    _description = 'flight.rutas'
    _rec_name = "ruta_inicio_id"
    vuelo_planificado_id = fields.Many2one(string='Vuelo Planificado', comodel_name='flight.vuelos.planificados', ondelete='cascade',)
    ruta_inicio_id = fields.Many2one(string='Ruta Inicio', comodel_name='flight.ciudad', ondelete='restrict', required=True)
    ruta_fin_id = fields.Many2one(string='Ruta Fin', comodel_name='flight.ciudad', ondelete='restrict', required=True)
    horas_de_vuelo = fields.Float(string='Horas', compute="_value_pc", digits=(12, 1),)
    num_aterrizaje_tierra = fields.Integer(string='Apont/T',)
    num_aterrizaje_bordo = fields.Integer(string='Apont/B',)
    condicion = fields.Many2one(string='Condicion', comodel_name='flight.items', ondelete='restrict',
        domain=lambda self: [('catalogo_id', '=', self.env.ref('flight.catalogue_condicion').id)])       
    hora_decolage_tc = fields.Datetime(string='Decolage', default=fields.Datetime.now,)
    hora_estimada_arribo_tc = fields.Datetime(string='Hora estimada/arribo', default=fields.Datetime.now,)
    hora_aterrizaje_tc = fields.Datetime(string='Aterrizaje', default=fields.Datetime.now,)    
    registro_dotacion_ids = fields.One2many(string='Dotacion', comodel_name='flight.registro.dotacion', inverse_name='registro_dotacion_id', ondelete='cascade', 
                                            domain="[('aeronave_id_related', '=', 0)]",
                                            options="{'no_create_edit','=',True, 'no_open,'=', True,'no_create','=', True, 'no_quick_create','=', True}")
    bandera = fields.Integer(string='banderita', default=0)
    fecha_presentar_related = fields.Date(string="Fecha", related='vuelo_planificado_id.fecha_presentar', readonly=False)
    hora_inicio = fields.Datetime(string='Encendido', default=fields.Datetime.now,)    
    hora_fin = fields.Datetime(string='Apagado', default=fields.Datetime.now,)    
    band_volo = fields.Boolean(string='✔', default=False )
    state_related = fields.Selection(related='vuelo_planificado_id.state', store=True)    
    state_detalle_related = fields.Selection(related='vuelo_planificado_id.state', store=True)
  
    def write(self, values):
        if 'band_volo' in values:
            if (values['band_volo'] == False):
                values['horas_de_vuelo']=0
                values['num_aterrizaje_tierra']=0
                values['num_aterrizaje_bordo']=0
                values['registro_dotacion_ids']=[(5,0,0)]
                values['hora_inicio']=self.fecha_presentar_related
                values['hora_fin']=self.fecha_presentar_related               
        result = super(Rutas, self).write(values)    
        return result            

#   Boton para cargar la dotacion automaticamente del PVS
    def action_cargar(self):
            if(self.hora_fin):
                contenido = self.env['flight.rutas'].search([('id', '=', self._origin.id)])
                record = self.env['flight.vuelos.planificados'].browse(contenido.vuelo_planificado_id.id)
                contenido.registro_dotacion_ids=[(5,0,0)]
                new_recorset = record.piloto_id | record.copiloto_id | record.mecanico_ids | record.electronico_ids | record.electricista_ids | record.ingeniero_vuelo_id | record.radarista_id | record.taco_id
                for item in new_recorset:
                    contenido.registro_dotacion_ids = [(0, 0, {'tripulante_id': item.tripulante_id.id, 'habilitacion_id': item.habilitacion_id.id})]

#   Llenar autmaticamente la dotacion del PVS ACCIONAR TORRE DE CONTROL => Ejecucion. raise ValidationError("PVS # {}  RUTA # {}  DOTACION # => {}".format(contenido.vuelo_planificado_id.id,self._origin.id,listar))
    @api.onchange('hora_aterrizaje_tc')
    def _onchange_hora_aterrizaje_tc(self):
        if(self.hora_aterrizaje_tc):
            contenido = self.env['flight.rutas'].search([('id', '=', self._origin.id)])
            record = self.env['flight.vuelos.planificados'].browse(contenido.vuelo_planificado_id.id)
            if(not contenido.registro_dotacion_ids):
                new_recorset = record.piloto_id | record.copiloto_id | record.mecanico_ids | record.electronico_ids | record.electricista_ids | record.ingeniero_vuelo_id | record.radarista_id | record.taco_id
                for item in new_recorset:
                    contenido.registro_dotacion_ids = [(0, 0, {'tripulante_id': item.tripulante_id.id, 'habilitacion_id': item.habilitacion_id.id})]

#   Llenar autmaticamente la dotacion del PVS => Ejecucion. raise ValidationError("PVS # {}  RUTA # {}  DOTACION # => {}".format(contenido.vuelo_planificado_id.id,self._origin.id,listar))
    @api.onchange('hora_fin')
    def _onchange_hora_fin(self):
        if(self.hora_fin):
            contenido = self.env['flight.rutas'].search([('id', '=', self._origin.id)])
            record = self.env['flight.vuelos.planificados'].browse(contenido.vuelo_planificado_id.id)
            if(not contenido.registro_dotacion_ids):
                new_recorset = record.piloto_id | record.copiloto_id | record.mecanico_ids | record.electronico_ids | record.electricista_ids | record.ingeniero_vuelo_id | record.radarista_id | record.taco_id
                for item in new_recorset:
                    contenido.registro_dotacion_ids = [(0, 0, {'tripulante_id': item.tripulante_id.id, 'habilitacion_id': item.habilitacion_id.id})]

#   Calcular las horas voladas
    @api.depends('hora_inicio', 'hora_fin')
    def _value_pc(self):
        for rec in self:
            # Convertimos (timedelta) -> (segundos) o dias -> (horas)
            if rec.hora_fin !=0 and rec.hora_inicio !=0:
                def convert_timedelta(duration):
                    days, seconds = duration.days, duration.seconds
                    hours = days * 24 + seconds / 3600
                    minutes = (seconds % 3600) // 60
                    seconds = (seconds % 60)
                    return hours, minutes, seconds
                valor = rec.hora_fin - rec.hora_inicio
                hours, minutes, seconds = convert_timedelta(valor)
                # Si quiero presentar solo hora con minutos, quitarle el round(,1) y anexarle un widget="float_time"
            else:
                hours=0
                minutes=0
                seconds=0
            rec.horas_de_vuelo = round(float(hours), 1)            
            if rec.horas_de_vuelo < 0.0:
                raise ValidationError("NO PUEDES INGRESAR UNA HORA NEGATIVA. POR FAVOR VERIFIQUE LAS FECHAS %s" % (rec.horas_de_vuelo)) 
            elif rec.horas_de_vuelo > 0.0:
                if not(rec.registro_dotacion_ids):                    
                    if(rec.hora_fin):
                        contenido = self.env['flight.rutas'].search([('id', '=', self._origin.id)])
                        record = self.env['flight.vuelos.planificados'].browse(contenido.vuelo_planificado_id.id)
                        if(not contenido.registro_dotacion_ids):
                            new_recorset = record.piloto_id | record.copiloto_id | record.mecanico_ids | record.electronico_ids | record.electricista_ids | record.ingeniero_vuelo_id | record.radarista_id | record.taco_id
                            for item in new_recorset:
                                contenido.registro_dotacion_ids = [(0, 0, {'tripulante_id': item.tripulante_id.id, 'habilitacion_id': item.habilitacion_id.id})]
            # elif rec.registro_dotacion_ids != False and rec.horas_de_vuelo == 0.0:
            #     rec.registro_dotacion_ids=[(5,0,0)]
                    
                    # raise ValidationError("INGRESE LA DOTACION DE VUELO PARA LA RUTA %s - %s"% (rec.ruta_inicio_id.name,rec.ruta_fin_id.name)) 

#   name_get para el widget many2many_tags de rutas
    @api.depends('ruta_inicio_id', 'ruta_fin_id')
    def name_get(self):
        result = []
        ultimo = 0
        for table in self:
            l_name = table.ruta_inicio_id.acronimo + "-" + table.ruta_fin_id.acronimo
            result.append((table.id, l_name))
        return result


class Registro_Dotacion(models.Model):
    _name = 'flight.registro.dotacion'
    _description = 'flight.registro.dotacion'
    _rec_name = 'tripulante_id'
    # _order = "horas_de_vuelo_related desc"
    # _order="hora_inicio_related desc,habilitacion_id desc"

    registro_dotacion_id = fields.Many2one(string='Dotacion', comodel_name='flight.rutas', ondelete="cascade")
    aeronave_id_related = fields.Many2one(string='HN/AN', related="registro_dotacion_id.vuelo_planificado_id.aeronave_id", ondelete='restrict', store=True)  
    mision_related_ok = fields.Many2one(string='HN/AN', related="registro_dotacion_id.vuelo_planificado_id.mision", ondelete='restrict', store=True )   
    modelo_id_related = fields.Many2one(string='Modelo', related="aeronave_id_related.modelo_id" )
    tripulante_id = fields.Many2one(string='Tripulantes', comodel_name='hr.employee', ondelete='restrict',)
    habilitacion_id = fields.Many2one(string='Habilitaciones', comodel_name='flight.habilitaciones', ondelete='restrict',)
    hora_inicio_related = fields.Datetime(related='registro_dotacion_id.hora_inicio', readonly=False, store=True)
    hora_fin_related = fields.Datetime(related='registro_dotacion_id.hora_fin', readonly=False, store=True)
    horas_de_vuelo_related = fields.Float(string='total', related='registro_dotacion_id.horas_de_vuelo', compute="_value_pc", digits=(12, 1), store=True)

    @api.depends('tripulante_id', 'habilitacion_id')
    def name_get(self):
        result = []
        ultimo = 0
        for table in self:
            l_name = str(table.habilitacion_id.name) + \
                "-" + str(table.tripulante_id.name)
            result.append((table.id, l_name))
        return result
