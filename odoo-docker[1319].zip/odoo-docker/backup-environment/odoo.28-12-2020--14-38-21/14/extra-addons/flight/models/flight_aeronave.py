from odoo.exceptions import ValidationError
from odoo import models, fields, api
from string import ascii_letters, digits
import string 

class Aircraft(models.Model):
    _name = 'flight.aircraft'
    _description = 'flight.aircraft'   

    name = fields.Char(string="Numero de Matrícula", 
        required=True, size=10,)
    
    contador_historico = fields.Integer(
        string='Historico Tipo Seguro', compute="get_contador" )

    estado = fields.Selection(string='Estado',
        selection=[('OPERATIVO', 'OPERATIVO'), ('PRUEBA', 'PRUEBA'), ('NO OPERATIVO', 'NO OPERATIVO')],default="OPERATIVO" )
            
    tipo_aeronave_id = fields.Many2one(string='Tipo de aeronave', comodel_name='flight.items', 
        ondelete='restrict',domain=lambda self : [('catalogo_id', '=', self.env.ref('flight.catalogue_tipo_aeronave').id)], required=True )

    modelo_id = fields.Many2one(string='Modelo', comodel_name='flight.items', ondelete='restrict',
        domain=lambda self : [('catalogo_id', '=', self.env.ref('flight.catalogue_modelo').id)], required=True )
    
    escuadron_id2 = fields.Many2one(string='Escuadron', comodel_name='res.company',ondelete='restrict',)    
    fecha_adquisicion = fields.Date(string='Fecha de Adquisición', required=True)

    aeronavegabilidad = fields.Char(string='Certificado de Aeronavegabilidad', size=70)

    fabricante = fields.Char(string="Fabricante", size=70)

    anio_fabricacion = fields.Char(string='Año de Fabricación', required=True, size=4)

    envergadura = fields.Float(string='Envergadura',)

    tipo_turbina_id = fields.Many2one(string='Tipo de Turbina', comodel_name='flight.items',
        ondelete='restrict', domain=lambda self : [('catalogo_id', '=', self.env.ref('flight.catalogue_tipo_turbina').id)], required=True)
    
    potencia = fields.Float(string='Potencia', required=True )     

    tipo_motor_id = fields.Many2one(string='Tipo de Motor', comodel_name='flight.tipos.motores', 
        ondelete='restrict', required=True )    

    velocidad_maniobra = fields.Float(string='Velocidad de Maniobra', required=True)  

    longitud = fields.Float(string='Longitug', required=True)
    
    altura = fields.Float(string='Altura', required=True)  

    velocidad_economica = fields.Float(string='Velocidad Económica', required=True)

    crucero_rapido= fields.Float(string='Velocidad de Crucero Rápido', required=True)

    crucero_lento = fields.Float(string='Velocidad de Crucero Lento', required=True)

    altura_maxima = fields.Float(string='Altura Máxima de Vuelo', required=True)
    
    mision_plan_vuelo_ids = fields.One2many(string='Misiones',comodel_name='flight.mision.planvuelo',
        inverse_name='aeronave_id')  
    
    equipo_deteccion_ids = fields.Many2many(string='Equipos de Detección',comodel_name='flight.equipo.deteccion',
        relation='aeronave_deteccion_rel', 
        column1='aircraft_id', column2='item_id', 
        ondelete='restrict', required=True )  

    equipo_comunicacion_ids = fields.Many2many(string='Equipos de Comunicación',comodel_name='flight.equipo.comunicacion',
        relation='aeronave_comunicacion_rel',
        column1='aircraft_id',column2='item_id',
        ondelete='restrict', required=True )  
      
    equipo_navegacion_ids = fields.Many2many(string='Equipos de Navegación',comodel_name='flight.equipo.navegacion',
        relation='aeronave_navegacion_rel',
        column1='aircraft_id', column2='item_id',
        ondelete='restrict', required=True )    

    num_maximo_pasajeros = fields.Integer(string='Número Máximo Permitido de Pasajeros', required=True )
    
    num_maximo_carga = fields.Float(string='Número Máximo Dotación de Vuelo', )

    peso_max_pasajero = fields.Float(string='Peso Máximo Permitido por Pasajero', required=True)

    peso_tot_combustible = fields.Float(string='Peso total de combustible',required=True)

    peso_max_despegue = fields.Float(string='Peso máximo de despegue',required=True) 
  
    cambio_radiograma= fields.Char(string="Radiograma de Cambio de Seguro", required=True, size=70)

    observacion_seguro= fields.Text(string="Observaciones del seguro", required=True, size=250)      

    equip_adicional_ids = fields.Many2many(
        string='Equipos Adicionales', comodel_name='flight.addtional.equipment',
        relation='flight_additional_aircraft_rel', column1='aeronave_id',column2='adicional_id')   
    
    tipo_seguro_id = fields.Many2one(string='Tipo de Seguro', comodel_name='flight.items', ondelete='restrict',
        domain=lambda self : [('catalogo_id', '=', self.env.ref('flight.catalogue_tipo_seguro').id)])
    
    #Abrimos la vista historico
    def history_open_security_type(self):        
        return {
            'name': ('Historico Tipo de Seguro'),
            'domain': [('aeronave_id', '=', self.id)],
            'res_model': 'flight.aircraft.history.securitytype',
            'view_id': False,
            'view_mode': 'tree',
            'type': 'ir.actions.act_window',
        }

    def history_open_equipment(self):        
        return {
            'name': ('Historico Equipamiento Adicional'),
            'domain': [('aeronave_id', '=', self.id)],
            'res_model': 'flight.aircraft.history.equipment',
            'view_id': False,
            'view_mode': 'tree',
            'type': 'ir.actions.act_window',
        }   
    
    def get_contador(self):        
        contar= self.env['flight.aircraft.history.securitytype'].search_count([('aeronave_id', '=', self.id)])
        self.contador_historico=contar
    
    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()
    
    #Ingreso del historico
    @api.model
    def create(self, values): 
        self.transformar_mayuscula(values) 
        result = super(Aircraft, self).create(values)
        listar=[]
        for item in result.equip_adicional_ids:
             listar.append(item.name)
        vals={
            'tipo_seguro_id':values['tipo_seguro_id'],
            'radiograma_seguro':values['cambio_radiograma'],
            'observacion_seguro':values['observacion_seguro'],  
            'equipamento_adicional':str(listar), 
            'aeronave_id':result.id,
        }        
        self.env['flight.aircraft.history.securitytype'].create(vals)              
        return result    
   
    #actualizacion de historico
    def write(self, values): 
        self.transformar_mayuscula(values)       
        result = super(Aircraft, self).write(values)
        if 'equip_adicional_ids' in values:
            listar=[]
            for item in self.equip_adicional_ids:
                listar.append(item.name)
            if 'tipo_seguro_id' in values:               
                vals={
                    'tipo_seguro_id':int(self.tipo_seguro_id),
                    'radiograma_seguro':values['cambio_radiograma'],
                    'observacion_seguro':values['observacion_seguro'],
                    'equipamento_adicional':str(listar), 
                    'aeronave_id':self.id,
                }
                self.env['flight.aircraft.history.securitytype'].create(vals) 
        return result  
    
    @api.onchange('tipo_seguro_id')
    def _onchange_field2(self):          
        if(int(self.tipo_seguro_id.catalogo_id)==4):        
            self.cambio_radiograma=""
            self.observacion_seguro=""             
            self.equip_adicional_ids = [(6, 0, [])]
        else:
            self.tipo_seguro_id=""
        
    warning = {'title': 'Advertancia!', 'message' : 'Your message.' }
   
    @api.onchange('name','anio_fabricacion','cambio_radiograma',)
    def _name_validation_name(self):
        flag=False
        if set(str(self.name)).difference(ascii_letters + digits + '-'):
            self.warning['message'] ="Caracteres Invalidos en campo NÚMERO DE MATRÍCULA"  
            flag=True 
            self.name=""                            
        if set(str(self.fabricante)).difference(ascii_letters + digits + '-'):  
            self.warning['message'] ="Caracteres Invalidos en campo FABRICANTE"   
            flag=True
            self.fabricante=""             
        if set(str(self.cambio_radiograma)).difference(ascii_letters + digits + '-'):
            self.warning['message'] ="Caracteres Invalidos en campo RADIOGRAMA DE CAMBIO DE SEGURO"      
            flag=True
            self.cambio_radiograma=""   
        if flag:                                 
            return {'warning': self.warning}
    
    @api.onchange('peso_max_despegue')
    def _peso_max_despegue_validate(self):
        if self.peso_max_despegue < (self.num_maximo_carga+self.num_maximo_pasajeros)*self.peso_max_pasajero+self.peso_tot_combustible:
            self.peso_max_despegue=""
            self.warning['message'] = "El peso máximo de despegue no puede ser menor\n(Número Máximo Dotación + Número Máximo Permitido de Pasajeros) * Peso Máximo Permitido por Pasajero)+ Peso total de combustible)"
            return {'warning': self.warning}   
      
    # def action_retornar_operativo(self):
    #     self.write({'estado': 'OPERATIVO'})

    # def action_pasar_prueba(self):
    #     self.write({'estado': 'PRUEBA'})

    # def action_pasar_no_operativo(self):
    #     self.write({'estado': 'NO OPERATIVO'})

    def action_retornar_prueba(self):
        self.write({'estado': 'PRUEBA'})