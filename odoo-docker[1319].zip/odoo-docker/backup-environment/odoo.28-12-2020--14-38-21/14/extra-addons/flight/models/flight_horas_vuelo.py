from odoo.exceptions import ValidationError
from odoo import models, fields, api
from string import ascii_letters, digits
import string


class Horas_vuelo(models.Model):
    _name = 'flight.horas.vuelo'
    _description = 'flight.horas.vuelos'

    gestionar = fields.Many2one(
        string='Periodo',
        comodel_name='flight.gestion.plan.semanal',
        ondelete='restrict',
    )

    fecha_busqueda = fields.Date(
        related="gestionar.vuelosplanificados_ids.fecha_vuelo",
        string='Fecha de vuelo', readonly=False,
        domain=[('fecha_vuelo', '>=', fields.Date.context_today)])

    aeronave_id = fields.Many2one(
        string='Aeronaves', related='gestionar.vuelosplanificados_ids.aeronave_id', ondelete='restrict',
        readonly=False
    )

    horas_vuelo_ids = fields.One2many(
        string='REGISTRO DE VUELOS EJECUTADOS',
        comodel_name='flight.vuelos.planificados',
        related='gestionar.vuelosplanificados_ids',
        readonly=False
    )

    copiloto_id = fields.Many2one(
        string='Copiloto', comodel_name='gestionar.vuelosplanificados_ids.copiloto_id', ondelete='restrict')

    state = fields.Selection([
        ('ACTIVO', 'ACTIVO'),
        ('PLANIFICADO', 'APROBADO JEFE DE OPERACIONES'),
        ('APROBADO_REPARTO', 'APROBADO COMANDANTE REPARTO'),
    ], string='Status', readonly=True, copy=False, index=True, tracking=3, default='ACTIVO')


    @api.onchange('aeronave_id','fecha_busqueda')
    def _cargar_vuelos(self):
        if(self.aeronave_id and self.fecha_busqueda):
            domain = ['&',('aeronave_id','=',int(self.aeronave_id)),('fecha_vuelo','=',self.fecha_busqueda)]
            record = self.env['flight.vuelos.planificados'].search(domain)
            id_vuelo = []
            for listar in record:
                id_vuelo.append(listar.id)
            self.horas_vuelo_ids = [(6,0,id_vuelo)]

    
    _sql_constraints = [
        ('name_unique',
         'UNIQUE(gestionar)',
         "Ya se encuentra en estado de Ejecucion de Vuelo.\n\nPor favor!\nRegrese a la vista anterior y busquela"),
    ]
    
    def action_retornar_activo(self):
        self.write({'state': 'ACTIVO'})

    def action_confirm_operador_reparto(self):
        self.write({'state': 'PLANIFICADO'})

    def action_confirm_comandante_reparto(self):
        self.write({'state': 'APROBADO_REPARTO'})
        if 'state' == 'APROBADO_REPARTO':
            self.warning['message'] = "APROBACION EXITOSA"
            return {'warning': self.warning}
    