from odoo.exceptions import ValidationError
from odoo import models, fields, api
from string import ascii_letters, digits
import string 


class Catalogue(models.Model):
    _name = 'flight.catalogue'
    _description = 'flight.catalogue'

    name = fields.Char(string="Nombre del Catalogo", required=True )

    items_ids = fields.One2many(string='Catalogo',comodel_name='flight.items',inverse_name='catalogo_id',)

    _sql_constraints = [('name_unique', 'UNIQUE(name)',"Catálogo debe ser único"),]    

    @api.constrains('name')
    def _check_name_catalogue_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))

    
    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base        
        self.transformar_mayuscula(values)
        result = super(Catalogue, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Catalogue, self).write(values)    
        return result

 
class Items(models.Model):
    _name = 'flight.items'
    _description = 'flight.items'

    name = fields.Char(string="Item", help='Escriba el nombre del item asociado a su catálogo',required=True,)    

    descripcion = fields.Char(string="Descripcion",required=True )
    
    catalogo_id = fields.Many2one(string='Catalogo',comodel_name='flight.catalogue',ondelete='restrict',)

    _sql_constraints = [('name_unique','UNIQUE(catalogo_id,name)',"Items debe ser único dentro de cada catálogo"),]    

    @api.constrains('name')
    def _check_name_items_insensitive(self):
        for record in self:
            model_ids = self.search(['&',('id', '!=',self.id),('catalogo_id', '=', int(self.catalogo_id))])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()
    
    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Items, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Items, self).write(values)    
        return result
    
    

class MisionClass(models.Model):
    _name = 'flight.mission.class'
    _description = 'flight.mission.class'
   
    name = fields.Char(string="Clase de Misión", required=True )

    acronimo = fields.Char(string="Acrónimo", required=True )

    categoria_mision_id = fields.Many2one(string='Categoria de la misión',
        comodel_name='flight.categoria.mision',ondelete='restrict', )
    


    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(MisionClass, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(MisionClass, self).write(values)    
        return result
    
   
    _sql_constraints = [('acronimo_unique','UNIQUE(acronimo)',"Misión debe ser único"),]    

    @api.constrains('acronimo')
    def _check_name_mision_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_acronimos = [x.acronimo.upper() for x in model_ids if x.acronimo]        
            if self.acronimo.upper() in list_acronimos:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.acronimo.upper()))


class CategoriaMision(models.Model):
    _name = 'flight.categoria.mision'
    _description = 'flight.categoria.mision'
    
    name = fields.Char(
        string='Nombre',
        required=True        
    )
    descripcion = fields.Char(
        string='Descripcion',
        required=True        
    )

    _sql_constraints = [('name_unique','UNIQUE(name)',"Categoria de misión debe ser único"),]    

    @api.constrains('name')
    def _check_name_categoria_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))


    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(CategoriaMision, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(CategoriaMision, self).write(values)    
        return result
   
    

class AdditionalEquipment(models.Model):
    _name = 'flight.addtional.equipment'
    _description = 'flight.addtional.equipment'
    _rec_name= "name"

    name = fields.Char(string="Equipo Adicional", required=True )

    descripcion = fields.Char(string="Descripcion", required=True )

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(AdditionalEquipment, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(AdditionalEquipment, self).write(values)    
        return result
    
    _sql_constraints = [('name_unique','UNIQUE(name)',"Equipos Adicionales debe ser único"),]    

    @api.constrains('name')
    def _check_name_equipamiento_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))

    
    
   
class Habilitaciones(models.Model):
    _name = 'flight.habilitaciones'
    _description = 'flight.habilitaciones'    
    
    name = fields.Char(string='Nombre',required=True)

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Habilitaciones, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Habilitaciones, self).write(values)    
        return result

    _sql_constraints = [('name_unique','UNIQUE(name)',"Habilitaciones debe ser único"),]    

    @api.constrains('name')
    def _check_name_habilitacion_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))
    


class MisionPlanVuelo(models.Model):
    _name = 'flight.mision.planvuelo'
    _description = 'flight.mision.planvuelo'
    _rec_name = 'mision_id'    
    
    mision_id = fields.Many2one(string='Mision',comodel_name='flight.mission.class', ondelete='restrict',)   
    
    aeronave_id = fields.Many2one(string='Aeronave',comodel_name='flight.aircraft',ondelete='restrict')

    _sql_constraints = [('id unico', 'unique(mision_id,aeronave_id)','Existen misiones duplicadas para esta aeronave')]


    
    
# class Escuadron(models.Model):
#     _name = 'flight.escuadron'
#     _description = 'flight.escuadron'   
    
#     name = fields.Char(string='Nombre',required=True)    
    
#     siglas = fields.Char(string='Siglas',)    
    
#     ciudad_id = fields.Many2one(string='Ciudad',comodel_name='flight.ciudad', ondelete='restrict',)

#     def transformar_mayuscula(self,values):
#         for k, v in values.items():
#             if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
#                 values[k] = values.pop(k).upper()        

#     @api.model
#     def create(self, values):
#         #guardar en mayuscula en  la base
#         self.transformar_mayuscula(values)
#         result = super(Escuadron, self).create(values)    
#         return result
    
#     def write(self, values):
#         #guardar en mayuscula en  la base
#         self.transformar_mayuscula(values)
#         result = super(Escuadron, self).write(values)    
#         return result

#     _sql_constraints = [('name_unique','UNIQUE(name)',"Escuadron debe ser único"),]    

#     @api.constrains('name')
#     def _check_name_escuadron_insensitive(self):
#         for record in self:
#             model_ids = self.search([('id', '!=',self.id)])        
#             list_names = [x.name.upper() for x in model_ids if x.name]        
#             if self.name.upper() in list_names:
#                 raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))
    


class Ciudad(models.Model):
    _name = 'flight.ciudad'
    _description = 'flight.ciudad'   
    
    name = fields.Char(string='Ciudad', required=True) 
    acronimo = fields.Char(string='Acronimo', required=True)     
    """
    provincia_id = fields.Many2one(string='Provincia',comodel_name='res.country.state',
        ondelete='restrict',
        domain=[('country_id','=',63)]
        )
    """
    
    

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()       

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Ciudad, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(Ciudad, self).write(values)    
        return result

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "Ciudad debe ser único"),
    ]    

    @api.constrains('name')
    def _check_name_ciudad_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))
     
    

class TiposMotores(models.Model):
    _name = 'flight.tipos.motores'
    _description = 'flight.tipos.motores'    
    
    name = fields.Char(string='Nombre',required=True)
    modelo = fields.Char(string='Modelo',)

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()       

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(TiposMotores, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(TiposMotores, self).write(values)    
        return result

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "Tipos de Motores debe ser único"),
    ]    

    @api.constrains('name')
    def _check_motor_name_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))

    

class EquipoDeteccion(models.Model):
    _name = 'flight.equipo.deteccion'
    _description = 'flight.equipo.deteccion'    
    
    name = fields.Char(string='Nombre',required=True)
    descripcion = fields.Char(string='Descripcion',)

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()       

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(EquipoDeteccion, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(EquipoDeteccion, self).write(values)    
        return result

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "Equipos de detección debe ser único"),
    ]    

    @api.constrains('name')
    def _check_deteccion_name_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))



class EquipoComunicacion(models.Model):
    _name = 'flight.equipo.comunicacion'
    _description = 'flight.equipo.comunicacion'    
    
    name = fields.Char(string='Nombre',required=True)
    descripcion = fields.Char(string='Descripcion',)

    def transformar_mayuscula(self,values):
        for k, v in values.items():
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):                
                values[k] = values.pop(k).upper()       

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(EquipoComunicacion, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(EquipoComunicacion, self).write(values)    
        return result

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "Equipos de comunicación debe ser único"),
    ]    

    @api.constrains('name')
    def _check_name_comunicacion_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))

    

class EquipoNavegacion(models.Model):
    _name = 'flight.equipo.navegacion'
    _description = 'flight.equipo.navegacion'    
    
    name = fields.Char(string='Nombre',required=True)
    descripcion = fields.Char(string='Descripcion',)

    def transformar_mayuscula(self,values):
        for k, v in values.items():            
            if set(str(values.get(k))).difference(digits) and values.get(k) and isinstance(values.get(k), str):            
                values[k] = values.pop(k).upper()       

    @api.model
    def create(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(EquipoNavegacion, self).create(values)    
        return result
    
    def write(self, values):
        #guardar en mayuscula en  la base
        self.transformar_mayuscula(values)
        result = super(EquipoNavegacion, self).write(values)    
        return result
    
    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "Equipos de navegación debe ser único"),
    ]    

    @api.constrains('name')
    def _check_navegacion_name_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe un registro con el nombre: %s " % (self.name.upper()))


    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
   
   
    

