# -*- coding: utf-8 -*-

from odoo import models, fields, api


class x_HrEmployeePublic(models.Model):
    _inherit = ['hr.employee.public']  
           
    
    crew_result_id = fields.Many2one(readonly=True,)
    crew_date_report = fields.Date(readonly=True)
    crew_referent_document = fields.Char(readonly=True) 
    crew_observation = fields.Char(readonly=True)
    quatification_ids = fields.One2many(readonly=True)
    crew_state = fields.Selection(selection=[('ACTIVO', 'ACTIVO'), ('CADUCADO', 'CADUCADO')],default="ACTIVO", readonly=True)