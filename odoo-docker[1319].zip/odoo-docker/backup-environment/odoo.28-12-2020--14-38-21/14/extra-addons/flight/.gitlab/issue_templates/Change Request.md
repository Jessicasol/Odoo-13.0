<!-- Sugiera un cambio de una caracteristica existente en el módulo de Gestión de TICS -->

## Descripción de caracteristica



## Descripción del Problema



## Cambio Propuesto



## Posibles Alternativas



## Información Adicional
