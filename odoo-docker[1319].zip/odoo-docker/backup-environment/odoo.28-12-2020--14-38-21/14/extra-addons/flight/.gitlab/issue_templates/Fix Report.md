<!-- Reportar un error encontrado mientras se usa o se desarolla el módulo de Gestión de TICS -->

## Descripción del Error


## Pasos para reproducir el error


## Comportamiento esperado


## Screenshots



## Detalles del Módulo (Versión, Navegador)



## Información Adicional	
