<!-- Crear una historia de usuario del producto deseado del módulo de Gestión de TICS -->

## Rol


## Descripción de Funcionalidad


## Razón o Resultado



<!--  Como un [Rol], necesito [Descripción de la Funcionalidad] con la finalidad de [Razón o Resultado]
Ejemplo:
Como Usuario [Tipo de Perfil], necesito tener la capacidad de realizar el ingreso, actualización de estado del inventario de activos informáticos y comunicaciones [Necesidad] con la finalidad de 
tener el control de existencias en los repartos de la Armada [Resultado]
-->
