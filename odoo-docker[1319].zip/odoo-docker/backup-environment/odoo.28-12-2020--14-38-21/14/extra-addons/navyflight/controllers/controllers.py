# -*- coding: utf-8 -*-
# from odoo import http


# class Navyflight(http.Controller):
#     @http.route('/navyflight/navyflight/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/navyflight/navyflight/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('navyflight.listing', {
#             'root': '/navyflight/navyflight',
#             'objects': http.request.env['navyflight.navyflight'].search([]),
#         })

#     @http.route('/navyflight/navyflight/objects/<model("navyflight.navyflight"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('navyflight.object', {
#             'object': obj
#         })
