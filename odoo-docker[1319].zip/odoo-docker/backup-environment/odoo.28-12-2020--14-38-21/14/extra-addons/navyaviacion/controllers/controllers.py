# -*- coding: utf-8 -*-
# from odoo import http


# class Navyaviacion(http.Controller):
#     @http.route('/navyaviacion/navyaviacion/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/navyaviacion/navyaviacion/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('navyaviacion.listing', {
#             'root': '/navyaviacion/navyaviacion',
#             'objects': http.request.env['navyaviacion.navyaviacion'].search([]),
#         })

#     @http.route('/navyaviacion/navyaviacion/objects/<model("navyaviacion.navyaviacion"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('navyaviacion.object', {
#             'object': obj
#         })
