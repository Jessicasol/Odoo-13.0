# -*- coding: utf-8 -*-
# from odoo import http


# class Tics/ticsProduct(http.Controller):
#     @http.route('/tics/tics_product/tics/tics_product/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/tics/tics_product/tics/tics_product/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('tics/tics_product.listing', {
#             'root': '/tics/tics_product/tics/tics_product',
#             'objects': http.request.env['tics/tics_product.tics/tics_product'].search([]),
#         })

#     @http.route('/tics/tics_product/tics/tics_product/objects/<model("tics/tics_product.tics/tics_product"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('tics/tics_product.object', {
#             'object': obj
#         })
