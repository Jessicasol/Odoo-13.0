# -*- coding: utf-8 -*-

from . import x_product_template
