
from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression

class x_ProductTemplate(models.Model):    
    _inherit = ['product.template']
    
    sale_ok = fields.Boolean(default=False)
    

class x_ProductAttribute(models.Model):
    _inherit = ['product.attribute']
   
    _sql_constraints = [('name_unique', 'UNIQUE(name)',"Nombre de la categoria debe ser unico!!"),] 

    @api.constrains('name')
    def _check_name_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe un atributo con el nombre: %s " % (record.name.upper()))           


class ProductAttributeValue(models.Model):
    _inherit = ['product.attribute.value']
   
    _sql_constraints = [('name_unique', 'UNIQUE(name, attribute_id)', "Nombre de la categoria debe ser unico!!"),] 
    
    @api.constrains('name')
    def _check_name_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe un valor con el nombre: %s " % (record.name.upper()))