# -*- coding: utf-8 -*-
##############################################################################
#
#    Odoo
#    Copyright (C) 2013-2019 CodUP (<http://codup.com>).
#
##############################################################################

from odoo.exceptions import ValidationError
from odoo import models, fields, api
import time

class MroAtender(models.TransientModel):
    _name = 'mro.atender'
    _description = 'mro.atender'

    descripcion = fields.Text('Descripción', required=True)

    def atender_ticket(self):       
        active_id = self._context.get('active_id')
        if active_id:
            request = self.env['mro.request'].browse(self._context.get('active_id'))
            if(request.tipo_atencion=="ACTIVO"):                           
                if not(request.responsable_id and request.servicio_id and request.subcategoria_id and request.categoria_id and request.asset_id):
                    raise ValidationError("Por favor complete la información de DATOS PRINCIPALES")
            else:
                if not(request.responsable_id and request.servicio_id and request.subcategoria_id and request.categoria_id ):
                    raise ValidationError("Por favor complete la información de DATOS PRINCIPALES")
           
            if not(request.tipo_servicio and request.impacto_id and request.urgencia):
                raise ValidationError("Por favor complete la información de CLASIFICACION")
            request.write({'solucion_ticket':self.descripcion,
                           'band_mesa_ayuda':True,
                           'es_crear_usuario':False,
                           'es_creacion':False,
                           'es_editar_categoria':True,
                           'execution_date': time.strftime('%Y-%m-%d %H:%M:%S'), 
                           'fecha_finalizacion': time.strftime('%Y-%m-%d %H:%M:%S')
                           })
            request.action_done()
        return {'type': 'ir.actions.act_window_close',}
