# -*- coding: utf-8 -*-
from odoo.exceptions import ValidationError
from odoo import models, fields, api
import time
import datetime
import odoo.addons.decimal_precision as dp

class x_Mro(models.Model):
    _inherit = ['mro.order']   
    
    STATE_SELECTION = [('draft', 'BORRADOR'), ('released', 'ESPERANDO PARTES'), ('ready', 'LISTO PARA MANTENIMIENTO'), ('done', 'HECHO'), 
                       ('cancel', 'CANCELADO'),]
    MAINTENANCE_TYPE_SELECTION = [('bm', 'Descompuesto'), ('cm', 'Correctivo')]  
    generado_id = fields.Many2one('res.users', 'Generado por')
    user_id = fields.Many2one('res.users', 'Generado por', default=lambda self: self._uid)
    state = fields.Selection(STATE_SELECTION, 'Status', readonly=True,
        help="Cuando se crea la orden de mantenimiento, el estado se establece en 'Borrador'.\n\
        Si se confirma el pedido, el estado se establece en 'Piezas en espera'.\n\
        Si el stock está disponible, el estado se establece en 'Listo para mantenimiento'.\n\
        Cuando finaliza el mantenimiento, el estado se establece en 'Listo'.", default='draft', )    
    maintenance_type = fields.Selection(MAINTENANCE_TYPE_SELECTION, 'Tipo de Mantenimiento', required=True, readonly=True,
                                        states={'draft': [('readonly', False)]}, default='bm')        
    asset_id = fields.Many2one('asset.asset', 'Activo',  readonly=True, states={'draft': [('readonly', False)]}, )    
    description = fields.Char('Descripción',)
    date_planned = fields.Datetime('Fecha de solicitud', required=True, readonly=True, states={'draft':[('readonly',False)]}, 
                                   default=time.strftime('%Y-%m-%d %H:%M:%S'), )      
    date_scheduled = fields.Datetime('Fecha Calendario', required=True, readonly=True, states={'draft':[('readonly',False)],
                                    'released':[('readonly',False)],'ready':[('readonly',False)]}, default=time.strftime('%Y-%m-%d %H:%M:%S'), )       
    date_execution = fields.Datetime('Fecha ejecucion', required=True, states={'done':[('readonly',True)],'cancel':[('readonly',True)]}, 
                                     default=time.strftime('%Y-%m-%d %H:%M:%S'), )       
    origin = fields.Char('Documento de Referencia', size=64, readonly=True, states={'draft': [('readonly', False)]}, 
                         help="Referencia del documento que generó esta orden de mantenimiento.", )    
    empleado_id = fields.Many2one(string='Responsable del mantenimiento', comodel_name='hr.employee', ondelete='restrict', 
                                  help='Persona que entrega el equipo')    
    parts_lines = fields.One2many('mro.order.parts.line', 'maintenance_id', 'Partes planificadas', readonly=True, 
                                  states={'draft':[('readonly',False)]}, ) 
    maintenance_type = fields.Selection(MAINTENANCE_TYPE_SELECTION, 'Tipo de Mantenimiento', required=True, readonly=True, 
                                        states={'draft': [('readonly', False)]}, default='bm')
    problem_description = fields.Text('Descripcion del problema', readonly=True)     
    stock_picking_ids = fields.One2many(string='Orden de Trabajo', comodel_name='stock.picking', inverse_name='order_id', readonly=True,)
    
    #CAMPOS NUEVOS
    tipo_mantenimiento_id = fields.Many2one('asset.items', 'Tipo de Mantenimiento', readonly=True, states={'draft': [('readonly', False)]},
                                            domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_tipo_mantenimiento").id)]) 
    tipo_atencion = fields.Selection(string='Tipo de Atención', selection=[('ACTIVO', 'MANTENIMIENTO'), ('SERVICIO', 'SERVICIO')], default='ACTIVO', 
                                     readonly=True, states={'draft': [('readonly', False)]})
    servicio_id = fields.Many2one(string='servicio', comodel_name='asset.categoria.servicio')
    subcategoria_id = fields.Many2one(string='Subcategoría (Motivo)', comodel_name='asset.subcategoria') 
    partes_recibidas_ids = fields.One2many(string='field_name', comodel_name='stock.move', inverse_name='order_id', readonly=True, )
    responsable_id = fields.Many2one('res.users', "Técnico Reponsable", readonly=True, states={'draft': [('readonly', False)]})    
    responsable_activo = fields.Char('Responsable del Activo',)
    
    #CAMPOS DE INFORME TECNICO
    descripcion = fields.Char(string='Descripción', )
    discrepancia_id = fields.Many2one(string='Discrepancia', comodel_name='asset.items', ondelete='restrict', 
                                      domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_discrepancia" ).id)])    
    causa_id = fields.Many2one(string='Causa', comodel_name='asset.items', ondelete='restrict',
                               domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_causa" ).id)])
    observacion = fields.Char(string='Observación',)  
    solucion = fields.Text(string='Solución',)    
    recomendacion = fields.Text(string='Recomendaciones',)  
    
    def  action_partes_recibidas(self):
        for order in self:
            order.write({'state':'ready','date_execution': time.strftime('%Y-%m-%d %H:%M:%S')})
        
    def action_confirm(self):                
        if (self.parts_lines):                       
            domain=[('company_id', '=', self.env.company.id),('code','=','outgoing')]
            picking_type=self.env['stock.picking.type'].search(domain)           
            if(len(picking_type)!=1):            
                raise ValidationError("La compañia cuenta con multiples ORDENES DE ENTREGA")         
            value_picking={
                'partner_id': self.env.user.partner_id.id,
                'picking_type_id': picking_type.id,
                'location_id': picking_type.default_location_src_id.id,
                'location_dest_id': self.env.ref("asset.stock_location_assets").id,           
                'state': 'draft',
                'order_id': self._origin.id,                       
            }                   
            registro = self.env['stock.picking'].create(value_picking)
            new_parts_lines = []   
            for line in self.parts_lines:
                new_parts_lines.append(
                    {
                        'picking_id': registro.id,
                        'name': line.parts_id.name,
                        'company_id': self.env.company.id,
                        'date': datetime.datetime.now(),
                        'product_id': line.parts_id.id,
                        'product_uom_qty': line.parts_qty,
                        'product_uom': 1,      
                        'location_id': picking_type.default_location_src_id.id,
                        'location_dest_id': self.env.ref("asset.stock_location_assets").id,
                        'state': "draft",
                        'procure_method': "make_to_stock", 
                        'order_id': self._origin.id,                                            
                })        
            self.env['stock.move'].create(new_parts_lines)
            for order in self:
                order.write({'state':'released'})  
        #es un servicio pasa a estado listo porque no necesita partes
        else:
            for order in self:
                order.write({'state':'ready','date_execution':time.strftime('%Y-%m-%d %H:%M:%S')})
        return 0

    def action_done(self):
        if(self.tipo_atencion=='ACTIVO'):
            if not (self.descripcion and self.discrepancia_id and self.observacion and self.solucion and self.causa_id and self.recomendacion):
                raise ValidationError("Por favor complete la información de INFORME TÉCNICO ")
        self.write({'state': 'done', 'date_execution': time.strftime('%Y-%m-%d %H:%M:%S')})
        for order in self:
            if order.request_id: order.request_id.action_done()
        return True
    


    
   

     
     
  
   
   
   