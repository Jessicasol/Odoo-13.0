
from odoo.exceptions import ValidationError
import time
from odoo import api, fields, models, _
from odoo import netsvc
import odoo.addons.decimal_precision as dp

class x_MroTask(models.Model): 
    _inherit = ['mro.task']

    MAINTENANCE_TYPE_SELECTION = [('cm', 'Correctivo'), ]
    category_id = fields.Many2one('asset.category', 'Categoria', ondelete='restrict', required=True)
    maintenance_type = fields.Selection(MAINTENANCE_TYPE_SELECTION, 'Tipo de Mantenimiento', required=True, default='cm')
    active = fields.Boolean('Activo', default=True)


class x_MroTaskPartsLine(models.Model):
    _inherit = ['mro.task.parts.line']

    name = fields.Char('Descripcion', size=64, )
    parts_id = fields.Many2one('product.product', 'Partes', required=True, )
    parts_qty = fields.Float('Cantidad', digits=dp.get_precision('Product Unit of Measure'), required=True, default=1.0, )
    parts_uom = fields.Many2one('uom.uom', 'Unidad de Medida', required=True, )
    task_id = fields.Many2one('mro.task', 'Tarea de Mantenimiento', )
    
    
class x_MroOrderPartsLine(models.Model):
    _inherit = ['mro.order.parts.line'] 
    
    name = fields.Char('Descripción', size=64, )
    parts_id = fields.Many2one('product.product', 'Partes', required=True, )
    parts_qty = fields.Float('Cantidad Solicitada', digits=dp.get_precision('Unidad de medida del producto'), required=True, default=1.0,)
    partes_recibidas = fields.Float('Cantidad Recibida', digits=dp.get_precision('Unidad de medida del producto'), required=True, default=0.0,)
    parts_uom = fields.Many2one('uom.uom', 'Unidad de medida', required=True, )
    maintenance_id = fields.Many2one('mro.order', 'Orden de Mantenimiento', )  
    stock_picking_type_id = fields.Many2one(string='Pedido/Devolución', comodel_name='stock.picking.type', ondelete='restrict', )
    


    
    








    