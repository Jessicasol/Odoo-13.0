
from odoo.exceptions import ValidationError
from odoo import models, fields, api
import time


class MantenimientoAnualPreventivo(models.Model): 
    _name = 'asset.mantenimiento.preventivo'
    _description = 'asset.mantenimiento.preventivo'    
    
    STATE_SELECTION = [('planificacion', 'PLANIFICACION'), ('ejecucion', 'EJECUCION'), ('fin', 'FINALIZADO')]
    name = fields.Char(string='Nombre', required=True, store=True, default='Plan de Mantenimiento Anual Preventivo ', compute='_concatenar_nombre' )    
    categoria_id = fields.Many2one(string='Categoria', comodel_name='asset.category', ondelete='restrict', required=True, ) 
    reparto_id = fields.Many2one(string='Reparto', comodel_name='res.company', ondelete='restrict', required=True, )         
    activo_ids = fields.One2many(string='Pivote', comodel_name='asset.mantenimiento.preventivo.activo', inverse_name='preventivo_id', ondelete='restrict' )
    state = fields.Selection(STATE_SELECTION, 'Estado', readonly=True, default='planificacion')
    
    @api.onchange('categoria_id','reparto_id')
    def _cargar_activos(self):        
        if(self.categoria_id and self.reparto_id):                
            domain=['&', ('reparto_id','=', int(self.reparto_id)), ('categoria_id', '=', int(self.categoria_id))]       
            record= self.env['asset.asset'].search(domain)            
            id_activo=[]
            #contar= self.env['asset.mantenimiento.preventivo.activo'].search_count([('preventivo_id', '=', self._origin.id)])                                    
            self.activo_ids = [(5,0,0)]
            for listar in record:                 
                self.activo_ids = [(0,0,{'preventivo_id':self.id, 'activo_id':listar.id})] 
        else:
            self.activo_ids = [(5,0,0)]          
                            
    @api.depends('reparto_id','categoria_id')
    def _concatenar_nombre(self): 
        self.name= "Plan de Mantenimiento Anual Preventivo "                       
        if(self.reparto_id):  
            record=self.env["res.company"].browse(self.reparto_id.id)                             
            self.name = self.name + str(record.siglas) + "-" + time.strftime('%Y') + " "
        if(self.categoria_id):           
            self.name = self.name + str(self.categoria_id.name)
    
    _sql_constraints = [('name_unique', 'UNIQUE(name)', "Solo se puede realizar una planificacion anual por categoria"),]   
    
    def action_confirmacion(self):
        for linea in self.activo_ids:
            if not(linea.soporte_id):
                raise ValidationError ("Por favor asigne a todos los activos un tecnico responsable!!")                    
        self.write({'state': 'ejecucion'})       
        return True      
    
    def action_finalizacion(self):
        self.write({'state': 'fin'})       
        return True  
    
    def action_regresar(self):
        self.write({'state': 'planificacion'})       
        return True       
    
    
#tabla pivote entre CARGA DE ACTIVOS para mantenimiento preventivo anual
class PlanMantenimientoPreventivoActivo(models.Model):
    _name = 'asset.mantenimiento.preventivo.activo'
    _description = 'asset.mantenimiento.preventivo.activo'
    _rec_name = "preventivo_id"  
    
    STATE_SELECTION = [('borrador', 'BORRADOR'), ('hecho', 'HECHO'),]  
    preventivo_id = fields.Many2one(string='Mantenimiento Preventivo', comodel_name='asset.mantenimiento.preventivo', ondelete='restrict', )
    activo_id = fields.Many2one(string='Activo', comodel_name='asset.asset', ondelete='restrict',)      
    icron = fields.Char(string='Icron', related='activo_id.asset_number', store=False, ondelete='restrict')    
    responsable_id = fields.Many2one(string='Responsable', related='activo_id.user_id', store=False, ondelete='restrict', )
    criticality_id = fields.Selection(string='Crítico', related='activo_id.criticality', store=False, ondelete='restrict', )    
    fecha_planificacion = fields.Date(string='Fecha Planificación',)    
    fecha_ejecucion = fields.Date(string='Fecha Ejecución',)    
    soporte_id = fields.Many2one(string='Soporte', comodel_name='res.users', ondelete='restrict', )    
    descripcion = fields.Char(string='Descripción', )
    discrepancia_id = fields.Many2one(string='Discrepancia', comodel_name='asset.items', ondelete='restrict', 
                                      domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_discrepancia" ).id)])    
    causa_id = fields.Many2one(string='Causa', comodel_name='asset.items', ondelete='restrict',
                               domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_causa" ).id)])
    observacion = fields.Char(string='Observación',)  
    solucion = fields.Text(string='Solución',)    
    recomendacion = fields.Text(string='Recomendaciones',)
    state = fields.Selection(STATE_SELECTION, 'Estado', default='borrador')   
    state_related = fields.Selection(related='preventivo_id.state', )   
    categoria_related = fields.Integer(related='preventivo_id.categoria_id.id', store=False, string="id categoria")
    reparto_related = fields.Integer(related='preventivo_id.reparto_id.id', store=False, string="id reparto")
    
    def action_finalizacion(self):
        if not (self.descripcion and self.discrepancia_id and self.observacion and self.solucion and self.causa_id and self.recomendacion):
            raise ValidationError("Por favor complete la información de INFORME TÉCNICO ")        
        self.write({'state': 'hecho','fecha_ejecucion': time.strftime('%Y-%m-%d %H:%M:%S')})       
        return True 
    
    def eliminar_registro(self):        
        if(self.fecha_ejecucion):
            raise ValidationError("No se puede eliminar este registro porque ya se realizo el mantenimiento preventivo!!!")
        else:                     
            self.unlink()
        return True  
    
    _sql_constraints = [('name_unique', 'UNIQUE(preventivo_id,activo_id)', "Activo duplicado!!"),]   
    
    
    

        
            
        
    
    
    



    
    
    
   
    


    
    
    








    