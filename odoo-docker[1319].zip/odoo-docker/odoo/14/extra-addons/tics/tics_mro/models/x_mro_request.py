# -*- coding: utf-8 -*-
from odoo.exceptions import ValidationError
from odoo import models, fields, api
import time


class x_MroRequest(models.Model):
    _inherit = ['mro.request']
    
    @api.model
    def default_origen(self):        
         return self.env.ref("tics_asset.items_origen_sistema").id       
    
    #CAMPOS HEREDADOS
    STATE_SELECTION = [('draft', 'Borrador'), ('claim', 'Generado'), ('run', 'ejecucion'), ('done', 'Listo'), ('reject', 'Rechazado'),
                       ('cancel', 'Cancelado'),]

    state = fields.Selection(STATE_SELECTION, 'Status', readonly=True,
        help="Cuando se crea la solicitud de mantenimiento, el estado se establece en 'Borrador'.\n\
        Si se envía la solicitud, el estado se establece en 'Reclamar'.\n\
        Si se confirma la solicitud, el estado se establece en 'ejecucion'.\n\
        Si se rechaza la solicitud, el estado se establece en 'Rechazado'.\n\
        Cuando finaliza el mantenimiento, el estado se establece en 'Listo'", track_visibility='onchange', default='draft', )       
    cause = fields.Char('Motivo', size=64, translate=False, required=True, readonly=True, states={'draft': [('readonly', False)]}, 
                        default='odoo dirctic',)
    breakdown = fields.Boolean('Descompuesto', readonly=True, states={'draft': [('readonly', False)]}, default=False, )    
    requested_date = fields.Datetime('Fecha Solicitada', default=False, required=True, readonly=True, )  
    execution_date = fields.Datetime('Fecha de Ejecución', required=False, readonly=True, states={'draft':[('readonly',False)], 
                                    'claim':[('readonly',False)]}, default=False, )
    fecha_finalizacion = fields.Datetime('Fecha de finalización', default=False, required=False, readonly=True, )   
    description = fields.Text('Descripción del problema', required=True, readonly=True, help='Por favor indique cual es el problema que presenta.')
    
    #CAMPOS NUEVOS     
    tipo_servicio = fields.Selection(string='Tipo de Servicio', selection=[('incidente', 'Incidente'), ('problema', 'Problema'),('cambio', 'Cambio')], )    
    urgencia= fields.Selection(string='Urgencia', selection=[('baja', 'Baja'), ('media', 'Media'),('alta', 'Alta'),('critica', 'Crítica')], )
    impacto_id = fields.Many2one('asset.items', 'Impacto', domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_impacto").id)]) 
    sequence_id = fields.Many2one('ir.sequence', 'Reference Sequence',check_company=True, copy=False)    
    name = fields.Char(string='Order Reference', required=True, copy=False, readonly=True, index=True, default=lambda self: ('Ticket'))    
    categoria_id = fields.Many2one(string='Categoria', comodel_name='asset.category', ondelete='restrict',readonly=False) 
    asset_id = fields.Many2one('asset.asset', 'Activo Fijo', readonly=False ) 
    company_id = fields.Many2one('res.company', 'Reparto', required=True, default=lambda s: s.env.company.id, index=True, )    
    user_id = fields.Many2one('res.users', "Usuario",  required=True, default=lambda s: s.env.user.id, domain="[('company_id', '=', company_id)]",)    
    tipo_atencion = fields.Selection(string='Tipo de Atención', selection=[('ACTIVO', 'MANTENIMIENTO'), ('SERVICIO', 'SERVICIO')], default='ACTIVO', )
    servicio_id = fields.Many2one(string='Servicio', comodel_name='asset.categoria.servicio', domain="[('categoria_id', '=', categoria_id)]", )
    subcategoria_id = fields.Many2one(string='Subcategoría (Motivo)', comodel_name='asset.subcategoria', )     
    motivo_id = fields.Many2one(string='Motivo', comodel_name='asset.items', ondelete='restrict', readonly=True, states={'claim': [('readonly', False)]}, 
                                domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_motivo").id)], )
    es_creacion = fields.Boolean(string='Es Creacion', store=True )  
     
    #campo para que se edite reparto y usuario cuando crea un usuario "MESA DE AYUDA"
    es_crear_usuario = fields.Boolean(string='Es Usuario mesa de ayuda', store=True )    
    es_editar_categoria = fields.Boolean(string='Es Editor Categoria', default=False, )    
    origen_id = fields.Many2one(string='Origen del Ticket', comodel_name='asset.items', ondelete='restrict', 
                                domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_origen").id)], default=default_origen,)
    solucion_ticket = fields.Text('Solucion Ticket', readonly=True)    
    band_mesa_ayuda = fields.Boolean(string='Bandera Mesa de Ayuda', default=False )
    responsable_id = fields.Many2one('res.users', "Asignar Técnico", domain=lambda self: [("company_id", "=", self.env.company.id)])      
    ayuda_usuario = fields.Text('Información de Categoria', related='categoria_id.descripcion', readonly=True, store=False )  
   
    #información del solicitante
    empleado_id = fields.Many2one('hr.employee', string='Nombre', readonly=True, store=True,) 
    grado = fields.Char(string='Grado', readonly=True, store=True)   
    reparto_id = fields.Char(string='Reparto', readonly=True, store=True) 
    email = fields.Char(string='Email', readonly=True, store=True)      
    celular = fields.Char(string='Celular', readonly=True, store=True)   
    especialidad_id = fields.Char(string='Especialidad', readonly=True, store=True)
    departamento_id = fields.Char(string='Departamento', readonly=True, store=True)    
       
    # funcion para crear una orden de mantenimiento  
    def action_confirm(self):       
        if(self.tipo_atencion=="ACTIVO"):            
            if not(self.responsable_id and self.servicio_id and self.subcategoria_id and self.categoria_id and self.asset_id):
                raise ValidationError("Por favor complete la información de DATOS PRINCIPALES")
        else:
            if not(self.responsable_id and self.servicio_id and self.subcategoria_id and self.categoria_id ):
                raise ValidationError("Por favor complete la información de DATOS PRINCIPALES")
                
        if not(self.tipo_servicio and self.impacto_id and self.urgencia):
            raise ValidationError("Por favor complete la información de CLASIFICACION")
        
        #bandera que se encarga de bloquear campos
        self.es_creacion= False    
        self.es_crear_usuario= False  
        self.es_editar_categoria= True  
        order_id = False
        order = self.env['mro.order']               
        for request in self:                           
            order_id = order.create({
                'date_planned':request.requested_date,
                'date_scheduled':request.requested_date,
                'date_execution':time.strftime('%Y-%m-%d %H:%M:%S'),
                'origin': request.name,
                'state': 'draft',
                'maintenance_type': 'bm',
                'asset_id': request.asset_id.id,
                'description': request.cause,
                'problem_description': request.description,
                'request_id': request.id,
                'tipo_atencion': request.tipo_atencion,
                'generado_id': request.user_id.id, 
                'servicio_id': request.servicio_id.id,
                'subcategoria_id': request.subcategoria_id.id, 
                'responsable_id': request.responsable_id.id,  
                'responsable_activo': request.asset_id.user_id.name,                         
                 })
            self.write({'state': 'run','execution_date': time.strftime('%Y-%m-%d %H:%M:%S') })      
        return order_id.id 
    
    #funcion para enviar la petición
    def action_send(self):  
        if(self.tipo_atencion=="ACTIVO" and self.es_crear_usuario==False):
            self.es_editar_categoria= True            
        value = {'state': 'claim'}
        for request in self:            
            value['requested_date'] = time.strftime('%Y-%m-%d %H:%M:%S')
            request.write(value)
           
    @api.onchange('company_id')
    def onchange_company_id(self):        
        if self.es_creacion:              
            self.categoria_id = False
            self.asset_id = False
            
    @api.onchange('es_creacion')
    def _onchange_usuario(self):
        if(self.es_creacion): 
            self.origen_id=False           
            return {'domain': {'origen_id': [('catalogo_id', '=', self.env.ref("tics_asset.asset_catalogo_origen").id),
                                             ('id', '!=', self.env.ref("tics_asset.items_origen_sistema").id)]}}    
      
    @api.onchange('categoria_id')
    def onchange_categoria_id(self):         
        self.asset_id= False 
        self.servicio_id = False
        self.subcategoria_id = False             
        for rec in self:
            return {'domain': {'asset_id': [('user_id', '=', rec.user_id.id),
                                            ('reparto_id', '=', rec.company_id.id),('categoria_id', '=', rec.categoria_id.id)]}}         
    
    @api.onchange('servicio_id')
    def onchange_servicio_id(self):        
        self.subcategoria_id= False         
        return {'domain': {'subcategoria_id': [('items_id', '=',self.servicio_id.servicio_id.id)]}}       
        
    @api.onchange('tipo_atencion')
    def _onchange_tipo_atencion(self):
        self.categoria_id = False
        self.asset_id = False
        self.servicio_id = False
        self.subcategoria_id = False 
       
    def action_reject(self):       
        self.write({'state': 'reject', 'fecha_finalizacion': time.strftime('%Y-%m-%d %H:%M:%S')})
        return True     
    
    @api.model
    def default_get(self, fields):           
        res = super(x_MroRequest, self).default_get(fields)    
        res["requested_date"]=time.strftime('%Y-%m-%d %H:%M:%S')                    
        domain=[('user_id','=',self.env.user.id),('company_id','=',self.env.user.company_id.id)]
        record=self.env["hr.employee"].search(domain)               
        if record:
            res["empleado_id"]=record.id  
            res["reparto_id"]=record.company_id.siglas                            
            res["grado"]=record.grado_id.name
            res["email"]=record.work_email             
            res["celular"]=record.mobile_phone     
            res["especialidad_id"]=record.especialidad_id.name   
            res["departamento_id"]=record.department_id.name                        
        return res
    
    def action_done(self):
        self.write({'state': 'done', 'fecha_finalizacion': time.strftime('%Y-%m-%d %H:%M:%S')})
        return True    
    
    @api.model
    def create(self, vals):  
        if vals.get('name', ('Ticket')) == ('Ticket'):       
            vals['name'] = self.env['ir.sequence'].next_by_code('mro.request.ticket') or ('Ticket')                   
        result = super(x_MroRequest, self).create(vals)
        return result



     
     
  
   
   
   