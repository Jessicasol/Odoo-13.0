# -*- coding: utf-8 -*-
{
    'name': "tics/tics_mro",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Dirtic",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    #agregue asset 15/10/2020
    #'depends': ['base','stock','th_gestion','asset','mro','tics_asset','tics_product','tics_stock','th_gestion_hr'],
    'depends': ['base','tics_stock','th_gestion_hr','mro','tics_product','stock'],
    # always loaded
    'data': [
        'security/x_mro_security.xml', 
        'security/ir.model.access.csv',              
        'data/sequence.xml',  
        'data/mro_user_data.xml', 
        'data/mro_equipos_data.xml', 
        'views/x_mro_menu_view.xml',                  
        'views/mro_atender_view.xml',           
        'views/mro_plan_mantenimiento_preventivo_view.xml', 
        'views/mro_mantenimiento_preventivo_activo_view.xml',                
        'views/x_mro_request_view.xml',        
        'views/x_mro_reject_view.xml', 
        'views/x_mro_order_view.xml',  
        'views/x_mro_menu_view.xml', 
        'views/x_product_template_view.xml',
        'views/templates.xml',
            
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
