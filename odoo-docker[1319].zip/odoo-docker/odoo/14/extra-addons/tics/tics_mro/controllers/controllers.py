# -*- coding: utf-8 -*-
# from odoo import http


# class Gestion-tics/baseMro(http.Controller):
#     @http.route('/gestion-tics/tics_mro/gestion-tics/tics_mro/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gestion-tics/tics_mro/gestion-tics/tics_mro/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('gestion-tics/tics_mro.listing', {
#             'root': '/gestion-tics/tics_mro/gestion-tics/tics_mro',
#             'objects': http.request.env['gestion-tics/tics_mro.gestion-tics/tics_mro'].search([]),
#         })

#     @http.route('/gestion-tics/tics_mro/gestion-tics/tics_mro/objects/<model("gestion-tics/tics_mro.gestion-tics/tics_mro"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gestion-tics/tics_mro.object', {
#             'object': obj
#         })
