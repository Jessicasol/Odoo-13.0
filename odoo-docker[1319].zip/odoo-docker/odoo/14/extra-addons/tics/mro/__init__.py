# -*- coding: utf-8 -*-
##############################################################################
#
#    Odoo
#    Copyright (C) 2013-2018 CodUP (<http://codup.com>).
#
##############################################################################

from . import asset
from . import mro
from . import stock
from . import product_template
from . import wizard
from . import models
