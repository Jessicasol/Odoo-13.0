# -*- coding: utf-8 -*-
# from odoo import http


# class Gestion-tics/baseTic(http.Controller):
#     @http.route('/gestion-tics/tics_asset/gestion-tics/tics_asset/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gestion-tics/tics_asset/gestion-tics/tics_asset/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('gestion-tics/tics_asset.listing', {
#             'root': '/gestion-tics/tics_asset/gestion-tics/tics_asset',
#             'objects': http.request.env['gestion-tics/tics_asset.gestion-tics/tics_asset'].search([]),
#         })

#     @http.route('/gestion-tics/tics_asset/gestion-tics/tics_asset/objects/<model("gestion-tics/tics_asset.gestion-tics/tics_asset"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gestion-tics/tics_asset.object', {
#             'object': obj
#         })
