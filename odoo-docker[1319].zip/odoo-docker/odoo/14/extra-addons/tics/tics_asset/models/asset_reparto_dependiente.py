
from odoo.exceptions import ValidationError
from odoo import models, fields, api

class AssetRepartoDependiente(models.Model): 
    _name = 'asset.reparto.dependiente'
    _description = 'asset.reparto.dependiente'    
    
    departamento_id = fields.Many2one(string='Departamento', comodel_name='hr.department', ondelete='restrict',
                                      domain=lambda self: [("company_id", "=", self.env.company.id)], required=True)       
    reparto_ids = fields.Many2many(string='Repartos Dependientes', comodel_name='res.company', relation='reparto_dependiente_company_rel', 
                                   column1 = 'reparto_dependiente_id', column2 = 'company_id',)
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda s: s.env.company.id, index=True,)
    
    _sql_constraints = [('name_unique', 'UNIQUE(departamento_id)', "El departamento ya tiene repartos dependientes!"),] 