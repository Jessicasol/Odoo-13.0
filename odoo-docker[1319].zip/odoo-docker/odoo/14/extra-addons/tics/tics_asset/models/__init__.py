# -*- coding: utf-8 -*-

from . import x_asset
from . import asset_componentes
from . import asset_reparto_dependiente
from . import asset_catalogo
from . import asset_periferico

