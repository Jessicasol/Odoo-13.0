
from odoo.exceptions import ValidationError
from odoo import models, fields, api

# Catálogo Componente
class x_AssetComponente(models.Model): 
    _name = 'asset.componente'
    _description = 'asset.componente'

    name = fields.Char('Nombre del Componente',required=True, )      
    categoria_id = fields.Many2one(string='Categoria', required=True, comodel_name='asset.category', ondelete='restrict', ) 
    atributo_ids = fields.One2many('asset.atributo', 'componente_id', string='Atributos', )      
   
    @api.onchange('attribute_id')
    def _onchange_field(self):
        self.atributo_id=int(self.attribute_id.atributo_id)
        
    _sql_constraints = [('name_unique', 'UNIQUE(categoria_id,name)',"Nombre del componente ya existe en esta categoría!!"),] 

    @api.constrains('name')
    def _check_name_componente_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id),('categoria_id', '=',record.categoria_id.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe un atributo con el nombre: %s " % (record.name.upper()))


# Catálogo atributos de componente
class x_AssetAtributo(models.Model): 
    _name = 'asset.atributo'
    _description = 'asset.atributo'

    name = fields.Char('Atributo',required=True, )       
    componente_id = fields.Many2one(string='Componente', comodel_name='asset.componente', ondelete='restrict', ) 
    valor_ids = fields.One2many('asset.atributo.valor', 'atributo_id', string='Valores', )  
    
    _sql_constraints = [('name_unique', 'UNIQUE(componente_id,name)',"Nombre del atributo ya existe para este componente!!"),] 

    @api.constrains('name')
    def _check_name_atributo_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id),('componente_id', '=',record.componente_id.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe un atributo con el nombre: %s " % (record.name.upper()))          
         
    
class Valores(models.Model): 
    _name = 'asset.atributo.valor'
    _description = 'asset.atributo.valor'

    name = fields.Char('Valor',required=True, )       
    atributo_id = fields.Many2one(string='Atributo', comodel_name='asset.atributo', ondelete='restrict', )   
    
    _sql_constraints = [('name_unique', 'UNIQUE(atributo_id,name)',"Nombre del valor ya existe en este atributo!!"),] 

    @api.constrains('name')
    def _check_name_atributo_valor_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id),('atributo_id', '=',record.atributo_id.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe un valor con el nombre: %s dentro de este atributo " % (record.name.upper()))  
            

# Tabla lineas de componente
class x_AssetLineasAtributo(models.Model): 
    _name = 'asset.lineas.atributo'
    _description = 'asset.lineas.atributo'
    
    categoria = fields.Integer(string='Categoria', )      
    atributo = fields.Integer(string='atributo', )  
    asset_id = fields.Many2one('asset.asset', string="Activos", ondelete='restrict', required=True, index=True, ) 
    componente_id = fields.Many2one(string='Componente', comodel_name='asset.componente', ondelete='restrict', 
                                    domain="[('categoria_id', '=', categoria)]")     
    atributo_id = fields.Many2one(string='Atributo', comodel_name='asset.atributo', ondelete='restrict', )       
    valor_id = fields.Many2one(string='Valor', required = True, comodel_name='asset.atributo.valor', ondelete='restrict', )
    


    
    
    
    
    
   
    


    
    
    








    