# -*- coding: utf-8 -*-

from odoo.exceptions import ValidationError
from odoo import models, fields, api

class x_AssetAsset(models.Model): 
    _inherit = ['asset.asset']
    
    warning = {'title': 'Advertancia!', 'message' : 'Your message.' }
    
    #NUEVOS CAMPOS
    reparto_id = fields.Many2one(string='Reparto', comodel_name='res.company', ondelete='restrict', required=True,
                                 default=lambda s: s.env.company.id, readonly=True )     
    categoria_id = fields.Many2one(string='Categoria', comodel_name='asset.category', ondelete='restrict', required=True, )     
    marca_id = fields.Many2one(string='Marca', comodel_name='asset.marca', ondelete='restrict', )    
    modelo_id = fields.Many2one(string='Modelo', comodel_name='asset.modelo', ondelete='restrict', domain="[('marca_id','=',marca_id)]", )     
    componentes_lineas_ids = fields.One2many('asset.lineas.atributo', 'asset_id', 'Atributos de componentes', )    
    periferico_ids = fields.One2many(string='Periférico', comodel_name='asset.periferico', inverse_name='activo_id',)   
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda s: s.env.company.id, index=True,)   
    empleado_id = fields.Many2one('hr.employee', string='Responsable del Activo',)
    user_id = fields.Many2one('res.users', 'Usuario', related='empleado_id.user_id', readonly=True, store=True,)    
    #CAMPO PARA ALMACENAR EL DETALLE
    attribute_line_ids = fields.One2many('asset.lineas.variantes', 'asset_id', 'Atributos de Activos', 
                                         domain="[('categoria_id', '=',categoria_id)]",)  
    #MODIFICACION DE CAMPOS EXISTENTES
    active = fields.Boolean('Active', default=False)
    CRITICALITY_SELECTION = [('0', 'General'), ('1', 'Importante'), ('2', 'Muy Importante'), ('3', 'Critico'), ]
    name = fields.Char(size=64, string="Nombre del Activo", required=True, translate=True, )         
    
    finance_state_id = fields.Many2one('asset.state', 'Estado', domain=[('team','=','0')], )
    warehouse_state_id = fields.Many2one('asset.state', 'Estado', domain=[('team','=','1')], )
    manufacture_state_id = fields.Many2one('asset.state', 'Estado', domain=[('team','=','2')], )
    maintenance_state_id = fields.Many2one('asset.state', 'Estado', domain=[('team','=','3')], )
    accounting_state_id = fields.Many2one('asset.state', 'Estado', domain=[('team','=','4')], )
    criticality = fields.Selection(CRITICALITY_SELECTION, 'Criticidad', )           
    active = fields.Boolean('Activo', default=True, )
    asset_number = fields.Char('Código ICRON', size=64, required=True)
    manufacturer_id = fields.Many2one('res.partner', 'Fabricante', )
    start_date = fields.Date('Fecha de inicio', )
    warranty_start_date = fields.Date('Inicio de Garantía', )
    purchase_date = fields.Date('Fecha de Compra', )
    warranty_end_date = fields.Date('Fin de Garantía', )  
    maintenance_date = fields.Datetime(string='Fecha de Mantenimiento') 
    
    _sql_constraints = [('name_unique', 'UNIQUE(name)',"Nombre  del activo debe ser único!!"),
                        ('asset_number_unique', 'UNIQUE(asset_number)',"Código  del activo debe ser único!!")]
        
    @api.onchange('categoria_id')
    def _onchange_categoria(self): 
        if (self.categoria_id):
          #  self.warning['message'] ="Si guarda los cambios perderá los componentes y caracteristicas ya ingresados en este activo"         
            self.componentes_lineas_ids = [(5,0,0)]
            self.attribute_line_ids = [(5,0,0)]
          #  return {'warning': self.warning}       
        
#herencia de ESTADO DE ACTIVO
class x_AssetState(models.Model):    
    _inherit = ['asset.state']

    STATE_SCOPE_TEAM = [ ('0', 'Finanzas'), ('1', 'Almacen'), ('2', 'Fabrica'), ('3', 'Mantenimiento'), ('4', 'Contabilidad'), ]   
    STATE_COLOR_SELECTION = [('0', 'Rojo'), ('1', 'Verde'), ('2', 'Azul'), ('3', 'Amarillo'), ('4', 'Fucsia'), ('5', 'Turquesa'), ('6', 'Negro'), 
                             ('7', 'Blanco'), ('8', 'Anaranjado'), ('9', 'Celeste'), ]  
    sequence = fields.Integer('Secuencia', help="Se usa para ordenar los estados.", default=1)
    team = fields.Selection(STATE_SCOPE_TEAM, 'Grupos')  
    state_color = fields.Selection(STATE_COLOR_SELECTION, 'Colores')
    name = fields.Char('Estado')    
    state = fields.Selection([('ACTIVO', 'ACTIVO'), ('MANTENIMIENTO', 'MANTENIMIENTO'), ('BAJA', 'BAJA'), ], string='Status', default='ACTIVO')     
    
    
# herencia de CATEGORIA DE ACTIVO
class x_AssetCategoria(models.Model): 
    _inherit = ['asset.category']
    
    name = fields.Char('Categorias (Etiquetas)')      
    product_attribute_ids = fields.One2many(string='Caracteristicas', comodel_name='asset.categoria.atributo', inverse_name='categoria_id', )   
    categoria_servicio_ids = fields.One2many(string='Servicios', comodel_name='asset.categoria.servicio', inverse_name='categoria_id', )   
    grupo_id = fields.Many2one(string='Grupo', comodel_name='asset.grupo', required=True, ondelete='restrict', )
    descripcion = fields.Text('Descripción', )    
    
    _sql_constraints = [('name_unique', 'UNIQUE(name)',"Nombre de la categoria debe ser unico!!"),] 

    @api.constrains('name')
    def _check_name_categoria_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe una categoría con el nombre: %s " % (record.name.upper()))
            
        

 
#TABLA DE DETALLE DE CARACTERISTICAS
class LineasVariante(models.Model):
    _name = "asset.lineas.variantes"
    _description = 'asset.lineas.variantes'
    _rec_name = 'attribute_id'

    asset_id = fields.Many2one('asset.asset', string="Activos", ondelete='restrict', required=True, index=True, )     
    categoria_id = fields.Integer(string='Categoria',)  
    attribute_id = fields.Many2one('asset.categoria.atributo', string="Atributos",  domain="[('categoria_id', '=', categoria_id)]", required=True, ) 
    atributo_id = fields.Integer(string='atributo', )  
    value_ids = fields.Many2many(string='Valores', comodel_name='product.attribute.value', relation='asset_lineas_valores_rel', column1='lineas_id',
                                 column2='valores_id', domain="[('attribute_id', '=', atributo_id)]", required=True, )
    
    @api.onchange('attribute_id')
    def _onchange_field(self):
        self.atributo_id=int(self.attribute_id.atributo_id)      
          

#CARACTERISTICAS 
class CategoriaAtributo(models.Model):
    _name = 'asset.categoria.atributo'
    _description = 'asset.categoria.atributo'
    _rec_name = 'atributo_id'   

    categoria_id = fields.Many2one(string='Categoria', comodel_name='asset.category', ondelete='restrict', required=True, )     
    atributo_id = fields.Many2one(string='Atributo', comodel_name='product.attribute', ondelete='restrict', required=True, )   

    _sql_constraints = [('name_unique', 'UNIQUE(categoria_id,atributo_id)',"Nombre del atributo ya ha sido asignado a esta categoría!!"),] 

    