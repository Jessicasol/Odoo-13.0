from odoo.exceptions import ValidationError
from odoo import models, fields, api
from string import ascii_letters, digits, whitespace

class Catalogo(models.Model):
    _name = 'asset.catalogo'
    _description = 'asset.catalogo'

    name = fields.Char(string="Nombre del Catalogo", required=True )
    items_ids = fields.One2many(string='Catalogo', comodel_name='asset.items', inverse_name='catalogo_id',)
    
    _sql_constraints = [('name_unique', 'UNIQUE(name)', "Catálogo debe ser único"),]    

  
class Items(models.Model):
    _name = 'asset.items'
    _description = 'asset.items'

    name = fields.Char(string="Nombre del Item", help='Escriba el nombre del item asociado a su catálogo', required=True,)   
    descripcion = fields.Char(string="Descripcion", required=True )    
    catalogo_id = fields.Many2one(string='Catalogo', comodel_name='asset.catalogo', ondelete='restrict',required=True,)    
    
    _sql_constraints = [('name_unique', 'UNIQUE(catalogo_id,name)', "Items debe ser único dentro de cada catálogo"),]   
    
    @api.model
    def create(self, values):  
        # self.transformar_mayuscula(values)
        result = super(Items, self).create(values)    
        return result
    
    def write(self, values): 
        # self.transformar_mayuscula(values)       
        result = super(Items, self).write(values)        
        return result  
    
    
class Marca(models.Model): 
    _name = 'asset.marca'
    _description = 'Asset'

    name = fields.Char('Marca',required=True)  
    
    _sql_constraints = [('name_unique', 'UNIQUE(name)', "Ya existe esta marca!!"),]
    
    @api.constrains('name')
    def _check_name_marca_insensitive(self):
        for record in self:
            model_ids = record.search([('id', '!=',record.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if record.name.upper() in list_names:
                raise ValidationError("Ya existe la marca: %s , no se permiten valores duplicados" % (record.name.upper()))  
                

class Modelo(models.Model): 
    _name = 'asset.modelo'
    _description = 'Asset'
    
    name = fields.Char('Modelo',required=True)
    marca_id = fields.Many2one(string='Marca', comodel_name='asset.marca', ondelete='restrict', )  
   
    _sql_constraints = [('name_unique', 'UNIQUE(name)', "Ya existe esta marca!!"),]
    
    @api.constrains('name')
    def _check_name_modelo_insensitive(self):
        for record in self:
            model_ids = self.search([('id', '!=',self.id),('marca_id', '=',self.marca_id.id)])        
            list_names = [x.name.upper() for x in model_ids if x.name]        
            if self.name.upper() in list_names:
                raise ValidationError("Ya existe el modelo: %s , no se permiten valores duplicados dentro de la misma marca!!" % (self.name.upper()))  
        

#SUBCATEGORIA DE SERVICIOS
class SubCategoria(models.Model):
    _name = 'asset.subcategoria'
    _description = 'asset.subcategoria'
    
    name = fields.Char(string="Nombre de la Subcategoria", help='Escriba el nombre de la subcategoria', required=True,)   
    descripcion = fields.Char(string="Descripcion", required=True )    
    items_id = fields.Many2one(string='Servicios', comodel_name='asset.items', ondelete='restrict',required=True, 
                               domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_servicio").id)])    
    
    _sql_constraints = [('name_unique', 'UNIQUE(items_id,name)', "Subcategoria debe ser único dentro de cada Items"),]  
   
    @api.model
    def create(self, values):          
        result = super(SubCategoria, self).create(values)    
        return result
    
    def write(self, values):            
        result = super(SubCategoria, self).write(values)        
        return result  
    
class GrupoCategoria(models.Model):
    _name = 'asset.grupo'
    _description = 'asset.grupo'
    
    name = fields.Char(string="Nombre del Grupo", help='Escriba el nombre del Grupo', required=True,)   
    
    _sql_constraints = [('id_unico', 'unique(name)','Ya existe un grupo con este nombre')]
    
#TABLA PIVOTE CATEGORIA SERVICIOS
class Asset_Categoria_Servicios (models.Model):
    _name = "asset.categoria.servicio"
    _description = 'asset.categoria.servicio'    
    _rec_name = 'servicio_id'
    
    categoria_id = fields.Many2one(string='Categoria', comodel_name='asset.category', ondelete='restrict', )
    servicio_id = fields.Many2one(string='Servicios', comodel_name='asset.items', ondelete='restrict', 
                                  domain=lambda self: [("catalogo_id", "=", self.env.ref( "tics_asset.asset_catalogo_servicio").id)])
    
    _sql_constraints = [('id_unico', 'unique(categoria_id,servicio_id)','Existen servicios duplicados para esta categoría')]
  



    
    
    
    
    
    
    
    
   
   
    

