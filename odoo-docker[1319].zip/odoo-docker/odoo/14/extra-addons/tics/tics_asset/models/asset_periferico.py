from odoo.exceptions import ValidationError
from odoo import models, fields, api
import logging
_logger = logging.getLogger(__name__)
from datetime import datetime,date

class Periferico(models.Model):
    _name = 'asset.periferico'
    _description = 'asset.periferico'

    name = fields.Char(string="Nombre", required=True )
    marca_id = fields.Many2one(string='Marca', comodel_name='asset.marca', ondelete='restrict',  )    
    modelo_id = fields.Many2one(string='Modelo', comodel_name='asset.modelo', ondelete='restrict', domain="[('marca_id','=',marca_id)]", )         
    vida_util = fields.Integer(string='Vida util', required=True, default=5)    
    fecha_inicio = fields.Date('Fecha de Inicio', required=True )   
    activo_id = fields.Many2one(string='Activo', comodel_name='asset.asset', ondelete='restrict', )
    porcentaje = fields.Integer()     
            
    def calcular(self):       
        if(self.vida_util != 0 and self.fecha_inicio):
            fmt = '%Y-%m-%d'
            start_date = self.fecha_inicio          
            start = datetime.strptime(str(start_date), '%Y-%m-%d').date()
            end = datetime.strptime(str(date.today()), '%Y-%m-%d').date()       
            if end >= start :
                diferencia = (end - start).days
                self.porcentaje=  int(diferencia/365/self.vida_util*100)
            else:
                raise ValidationError("Fecha de Inicio no puede ser mayor a la fecha actual!!")
        else:
            self.porcentaje = 0       
     
    def cron(self):
        _logger.info("NO HAY CAMBIO EN NAME ")    
        
           
        
       
        
        
       
    
    
    
    
    
  
    
    
    
    
    
    
    
   
 
    
    
    
    
    
    

    
    
    
    
    
    
    
    
   
   
    

