# -*- coding: utf-8 -*-
# from odoo import http


# class Tics/ticsStock(http.Controller):
#     @http.route('/tics/tics_stock/tics/tics_stock/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/tics/tics_stock/tics/tics_stock/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('tics/tics_stock.listing', {
#             'root': '/tics/tics_stock/tics/tics_stock',
#             'objects': http.request.env['tics/tics_stock.tics/tics_stock'].search([]),
#         })

#     @http.route('/tics/tics_stock/tics/tics_stock/objects/<model("tics/tics_stock.tics/tics_stock"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('tics/tics_stock.object', {
#             'object': obj
#         })
