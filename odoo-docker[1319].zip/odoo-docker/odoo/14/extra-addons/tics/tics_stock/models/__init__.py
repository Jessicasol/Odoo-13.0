# -*- coding: utf-8 -*-

from . import solicitud_catalogacion
from . import x_stock_picking

