# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date
from datetime import datetime
from odoo.exceptions import UserError

class x_StockPicking(models.Model):   
  _inherit = ['stock.picking']
    
  
  order_id = fields.Many2one(string='Orden de Mantenimiento', comodel_name='mro.order', ondelete='restrict',)
  

class x_StockMove(models.Model):   
  _inherit = ['stock.move']
    
  
  order_id = fields.Many2one(string='Orden de Mantenimiento', comodel_name='mro.order', ondelete='restrict',)
  
   
    
