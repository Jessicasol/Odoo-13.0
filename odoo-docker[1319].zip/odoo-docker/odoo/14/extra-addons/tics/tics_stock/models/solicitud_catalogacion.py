# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date
from datetime import datetime


class SolicitudCatalogacion(models.Model):
    _name = 'stock.catalogacion'
    _description = 'stock.catalogacion'  
    
    seleccion_estado = [('draft', 'Borrador'), ('solicitud', 'Solicitud'), ('aprobacion', 'Aprobación'), ('rechazo', 'Rechazo'),]     
    state = fields.Selection(seleccion_estado, 'Status', readonly=True, default='draft')    
    categoria_id = fields.Many2one(string='Categoria', comodel_name='product.category', ondelete='restrict', )    
    name = fields.Char(string='Nombre Comercial', )    
    fabricante_id = fields.Many2one(string='Fabricante', comodel_name='res.company', ondelete='restrict',)    
    descripcion = fields.Text(string='Descripcion', )
    destino_id = fields.Many2one(string='Destino del bien', comodel_name='res.company', ondelete='restrict',)   
    attribute_line_ids = fields.One2many('stock.lineas.variantes', 'catalogacion_id', 'Atributos de Catalogación', domain="[('categoria_id', '=',categoria_id)]", )       
    user_id = fields.Many2one('res.users','User', default=lambda self: self.env.user)    
    empleado_id = fields.Many2one('hr.employee', string='Nombre', readonly=True, store=False) 
    grado = fields.Char(string='Grado', readonly=True, store=False)   
    reparto_id = fields.Char(string='Reparto', readonly=True, store=False) 
    email = fields.Char(string='Email', readonly=True, store=False)       
    fecha = fields.Date(string='Fecha de Generación', readonly=True, store=False )
    duracion_dias = fields.Char(string='Tiempo del Trámite', readonly=True, store=False )    
    numero_partes = fields.Integer(string='Número de Parte Referido', )
    unidad_referida = fields.Char(string='Unidad Referida', )
    precio_referencial = fields.Char(string='Precio Referencial')  
    partida_presupuestaria = fields.Char(string='Partida Presupuestaria', )
    cuenta_contable = fields.Char(string='Partida Presupuestaria', ) 
    tipo_bien = fields.Char(string='Tipo de Bien', )
    ncmef = fields.Char(string='NCMEF', )
    cpc = fields.Char(string='CPC', )
    catalogo_anterior = fields.Char(string='Número de Catálogo Anterior', )
    
    def diff_dates(self, date2, date1):
        return abs(date2-date1).days   
    
    @api.model
    def default_get(self, fields):
        res = super(SolicitudCatalogacion, self).default_get(fields)
        domain=[('user_id','=',self.env.user.id),('company_id','=',self.env.user.company_id.id)]
        record=self.env["hr.employee"].search(domain)         
        if record:
            res["empleado_id"]=record.id  
            res["reparto_id"]=record.company_id.siglas                            
            res["grado"]=record.grado_id.name
            res["email"]=record.work_email
            res["fecha"]=record.create_date
            res["duracion_dias"]= str(abs(datetime.now()-record.create_date).days)          
            #raise ValidationError("hoy {}, fecha de reporte {}, diferncia ".format(datetime.now(),record.create_date))
        return res
        
    
    
    
   
    
    def action_send(self):
      self.write({'state': 'solicitud'})
      
    def action_solicitud(self):
      self.write({'state': 'aprobacion'})
      
    def action_cancel(self):
      self.write({'state': 'rechazo'})

   
class CatalogacionLineasVariantes(models.Model):
    _name = "stock.lineas.variantes"
    _description = 'stock.lineas.variantes'
    _rec_name = 'attribute_id'

    catalogacion_id = fields.Many2one('stock.catalogacion', string="Catalogación", ondelete='restrict', required=True, index=True, )     
    categoria_id = fields.Integer(string='Categoria', )  
    attribute_id = fields.Many2one('stock.categoria.atributo', string="Atributos",  domain="[('categoria_id', '=', categoria_id)]", ) 
    atributo_id = fields.Integer(string='atributo', )  
    value_ids = fields.Many2many(string='Valores', comodel_name='product.attribute.value', relation='stock_lineas_valores_rel', column1='lineas_id',
                                 column2='valores_id', domain="[('attribute_id', '=', atributo_id)]", )
    
    _sql_constraints = [('name_unique','UNIQUE(categoria_id,attribute_id)',"Descripcion ya existe en esta categoria!!"),]  
    
    @api.onchange('attribute_id')
    def _onchange_field(self):
        self.atributo_id=int(self.attribute_id.atributo_id)
  
  
    
      
          
#CREANDO MI PROPIA TABLA PIVOTE
class CatalogacionPivote(models.Model):
    _name = 'stock.categoria.atributo'
    _description = 'stock.categoria.atributo'
    _rec_name = 'atributo_id'   

    categoria_id = fields.Many2one(string='Categoria', comodel_name='product.category', ondelete='cascade', )     
    atributo_id = fields.Many2one(string='Atributos', comodel_name='product.attribute', ondelete='cascade', )  
    
    _sql_constraints = [('name_unique','UNIQUE(atributo_id,categoria_id)',"Descripción ya existe en esta categoria!!"),] 
    
    
    

