# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError

class practica(models.Model):
    _name = 'practica.practica'
    _description = 'practica.practica'

    name = fields.Char()
    value = fields.Integer()
    value2 = fields.Float(compute="_value_pc", store=True)
    description = fields.Text()

    @api.depends('value')
    def _value_pc(self):
        for record in self:
            record.value2 = float(record.value) / 100
            
            
    
    
    def funcion_mapped(self):  
        valores = self.env["res.partner"].search([])
        test = valores.mapped("name")        
        #ordenar
        sorted = valores.sorted(lambda o: o.company_id, reverse=True) 
        raise ValidationError("llego {}".format(sorted))
