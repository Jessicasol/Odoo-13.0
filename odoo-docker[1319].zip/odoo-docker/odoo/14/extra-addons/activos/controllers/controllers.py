# -*- coding: utf-8 -*-
# from odoo import http


# class Activos(http.Controller):
#     @http.route('/activos/activos/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/activos/activos/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('activos.listing', {
#             'root': '/activos/activos',
#             'objects': http.request.env['activos.activos'].search([]),
#         })

#     @http.route('/activos/activos/objects/<model("activos.activos"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('activos.object', {
#             'object': obj
#         })
