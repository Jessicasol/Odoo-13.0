# -*- coding: utf-8 -*-
# from odoo import http


# class TestProduccion(http.Controller):
#     @http.route('/test_produccion/test_produccion/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/test_produccion/test_produccion/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('test_produccion.listing', {
#             'root': '/test_produccion/test_produccion',
#             'objects': http.request.env['test_produccion.test_produccion'].search([]),
#         })

#     @http.route('/test_produccion/test_produccion/objects/<model("test_produccion.test_produccion"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('test_produccion.object', {
#             'object': obj
#         })
